#!/bin/bash

# Script to rebuild Chat AI service
# Run with: sudo ./rebuild-chat.sh

set -e

echo "=== Rebuilding Chat AI Service ==="
echo ""

# Check if we're in the right directory
if [ ! -f "docker-compose.yml" ]; then
    echo "❌ Error: docker-compose.yml not found"
    echo "Please run this script from the qa-dashboard-release directory"
    exit 1
fi

echo "Step 1/5: Stopping chat-ai container..."
docker-compose stop chat-ai || true

echo ""
echo "Step 2/5: Removing old container..."
docker-compose rm -f chat-ai || true

echo ""
echo "Step 3/5: Rebuilding chat-ai image (this may take a minute)..."
docker-compose build --no-cache chat-ai

echo ""
echo "Step 4/5: Starting chat-ai container..."
docker-compose up -d chat-ai

echo ""
echo "Step 5/5: Waiting for service to be ready..."
sleep 3

echo ""
echo "=== Status Check ==="
docker ps --filter "name=qa-dashboard-chat-ai" --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"

echo ""
echo "=== Testing Health Endpoint ==="
curl -s http://localhost:5482/health | python3 -m json.tool 2>/dev/null || curl -s http://localhost:5482/health

echo ""
echo ""
echo "=== Recent Logs ==="
docker logs qa-dashboard-chat-ai --tail 10

echo ""
echo "✅ Chat AI rebuilt successfully!"
echo ""
echo "Test the changes:"
echo "  - Open http://localhost:55480"
echo "  - Try: 'Show me a bar chart of assets by type'"
echo ""
echo "View live logs:"
echo "  sudo docker logs -f qa-dashboard-chat-ai"
