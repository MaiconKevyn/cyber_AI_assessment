#!/bin/sh
set -e

echo "Starting production server..."
exec npm run start