#!/bin/bash

# Script to index PDF documents for Chat AI RAG
# Run with: sudo ./index-docs.sh

set -e

echo "=== Indexing Documents for Chat AI ==="
echo ""

# Check if chat-ai container is running
if ! docker ps --format '{{.Names}}' | grep -q "qa-dashboard-chat-ai"; then
    echo "❌ Error: qa-dashboard-chat-ai container is not running"
    echo "Please start containers first with: sudo ./start-all.sh"
    exit 1
fi

echo "Indexing PDFs from docs/ directory..."
echo ""

docker exec -it qa-dashboard-chat-ai python app/scripts/index_documents.py

echo ""
echo "✅ Done! Documents indexed successfully."
echo "You can now ask questions about the documentation in the chat."
