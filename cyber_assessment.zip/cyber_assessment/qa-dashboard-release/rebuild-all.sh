#!/bin/bash

# Script to rebuild entire QA Dashboard stack
# Run with: sudo ./rebuild-all.sh

set -e

echo "=== Rebuilding Complete QA Dashboard Stack ==="
echo ""
echo "⚠️  WARNING: This will restart all services (app, chat-ai, db)"
echo ""
read -p "Continue? (y/N) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Cancelled."
    exit 0
fi

# Check if we're in the right directory
if [ ! -f "docker-compose.yml" ]; then
    echo "❌ Error: docker-compose.yml not found"
    echo "Please run this script from the qa-dashboard-release directory"
    exit 1
fi

echo ""
echo "Step 1/6: Stopping all containers..."
docker-compose down

echo ""
echo "Step 2/6: Rebuilding all images (this may take a few minutes)..."
docker-compose build --no-cache

echo ""
echo "Step 3/6: Starting all containers..."
docker-compose up -d

echo ""
echo "Step 4/6: Waiting for services to initialize..."
sleep 10

echo ""
echo "Step 5/6: Status check..."
docker-compose ps

echo ""
echo "Step 6/6: Health checks..."
echo ""
echo "Database:"
docker exec qa-dashboard-db psql -U postgres -d postgres -c "SELECT version();" 2>/dev/null | head -3 || echo "  ⚠️  Database not ready yet"

echo ""
echo "Chat AI:"
curl -s http://localhost:5482/health | python3 -m json.tool 2>/dev/null || echo "  ⚠️  Chat AI not ready yet"

echo ""
echo ""
echo "✅ All services rebuilt successfully!"
echo ""
echo "Next steps:"
echo "  1. Start dashboard: sudo docker exec -it qa-dashboard-app /start.sh"
echo "  2. Index documents: sudo docker exec -it qa-dashboard-chat-ai python app/scripts/index_documents.py"
echo "  3. Access: http://localhost:55480"
echo ""
echo "View logs:"
echo "  sudo docker-compose logs -f"
