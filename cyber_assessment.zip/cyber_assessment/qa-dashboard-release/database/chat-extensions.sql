-- Enable pgvector extension for vector similarity search
CREATE EXTENSION IF NOT EXISTS vector;

-- Table to store document chunks with embeddings
CREATE TABLE IF NOT EXISTS document_chunks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    content TEXT NOT NULL,
    embedding vector(1536),  -- OpenAI text-embedding-3-small dimension
    source_file TEXT NOT NULL,
    page_number INTEGER,
    section_title TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create HNSW index for fast similarity search
CREATE INDEX IF NOT EXISTS idx_document_chunks_embedding
ON document_chunks USING hnsw (embedding vector_cosine_ops);

-- Index for filtering by source file
CREATE INDEX IF NOT EXISTS idx_document_chunks_source
ON document_chunks(source_file);

-- Cache for NVD CVE lookups
CREATE TABLE IF NOT EXISTS cve_cache (
    cve_id TEXT PRIMARY KEY,
    data JSONB NOT NULL,
    fetched_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at TIMESTAMPTZ NOT NULL DEFAULT (now() + interval '7 days')
);

CREATE INDEX IF NOT EXISTS idx_cve_cache_expires_at
ON cve_cache(expires_at);
