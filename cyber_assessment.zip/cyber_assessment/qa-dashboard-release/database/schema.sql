-- Enable UUID support if needed
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

---------------------------------------------
-- ASSET TYPES (your "sitesTypes")
---------------------------------------------
CREATE TABLE asset_types (
  id          uuid PRIMARY KEY,
  slug        text NOT NULL UNIQUE,
  name        text NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);

---------------------------------------------
-- DEVICE CATEGORIES (your "device types")
---------------------------------------------
CREATE TABLE device_categories (
  id          uuid PRIMARY KEY,
  slug        text NOT NULL UNIQUE,
  name        text NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);

---------------------------------------------
-- ASSETS
---------------------------------------------
CREATE TABLE assets (
  id           uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  name         text NOT NULL,
  type_id      uuid NOT NULL REFERENCES asset_types(id) ON DELETE RESTRICT,
  created_at   timestamptz NOT NULL DEFAULT now()
);

---------------------------------------------
-- DEVICES
---------------------------------------------
CREATE TABLE devices (
  id                uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  name              text NOT NULL,
  asset_id          uuid NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  category_id       uuid NOT NULL REFERENCES device_categories(id) ON DELETE RESTRICT,
  created_at        timestamptz NOT NULL DEFAULT now()
);

---------------------------------------------
-- VULNERABILITIES (many-to-many with devices)
---------------------------------------------
CREATE TABLE vulnerabilities (
  id              uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  title           text        NOT NULL,
  description     text        NOT NULL,
  cve             text,
  discovery_date  date        NOT NULL,
  created_at      timestamptz NOT NULL DEFAULT now()
);

---------------------------------------------
-- DEVICE_VULNERABILITIES (join table)
---------------------------------------------
CREATE TABLE device_vulnerabilities (
  device_id         uuid NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
  vulnerability_id  uuid NOT NULL REFERENCES vulnerabilities(id) ON DELETE CASCADE,
  PRIMARY KEY (device_id, vulnerability_id)
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_assets_type_id ON assets(type_id);
CREATE INDEX IF NOT EXISTS idx_devices_asset_id ON devices(asset_id);
CREATE INDEX IF NOT EXISTS idx_devices_category_id ON devices(category_id);
CREATE INDEX IF NOT EXISTS idx_device_vulnerabilities_device_id ON device_vulnerabilities(device_id);
CREATE INDEX IF NOT EXISTS idx_device_vulnerabilities_vulnerability_id ON device_vulnerabilities(vulnerability_id);
CREATE INDEX IF NOT EXISTS idx_vulnerabilities_discovery_date ON vulnerabilities(discovery_date);
CREATE INDEX IF NOT EXISTS idx_vulnerabilities_cve ON vulnerabilities(cve);
