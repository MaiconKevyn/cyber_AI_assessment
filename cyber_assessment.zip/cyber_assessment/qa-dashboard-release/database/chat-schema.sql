-- Chat AI supplemental tables
-- Keeps RBAC overrides independent from core dashboard tables.

CREATE TABLE IF NOT EXISTS asset_permissions (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  asset_id uuid NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  role_name text NOT NULL,
  can_view boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (asset_id, role_name)
);
