#!/bin/bash

# Script to start QA Dashboard with Chat AI
# Run with: sudo ./start-all.sh

set -e

echo "=== QA Dashboard - Complete Start ==="
echo ""

# Check if .env file exists
if [ ! -f .env ]; then
    echo "❌ Error: .env file not found"
    echo "Please run: cp .env.example .env"
    echo "Then edit .env and set your OPENAI_API_KEY"
    exit 1
fi

# Check if OPENAI_API_KEY is set
if ! grep -q "OPENAI_API_KEY=sk-" .env; then
    echo "⚠️  Warning: OPENAI_API_KEY may not be set in .env"
    echo "Make sure you have: OPENAI_API_KEY=sk-..."
    read -p "Continue anyway? (y/N) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

echo "Step 1/5: Starting containers..."
docker-compose up -d

echo ""
echo "Step 2/5: Waiting for database to initialize (10 seconds)..."
sleep 10

echo ""
echo "Step 3/5: Checking container status..."
docker-compose ps

echo ""
echo "Step 4/5: Starting dashboard dev server..."
echo "Note: This will keep running in the foreground. Press Ctrl+C to stop."
echo "After the dashboard is running, open another terminal and run:"
echo "  sudo docker exec -it qa-dashboard-chat-ai python app/scripts/index_documents.py"
echo ""
read -p "Press Enter to start the dashboard..."

docker exec -it qa-dashboard-app /start.sh
