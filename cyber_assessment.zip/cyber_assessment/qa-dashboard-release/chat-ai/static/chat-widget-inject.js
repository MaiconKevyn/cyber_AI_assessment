/**
 * Sentry Intelligence Chat Widget Injector
 *
 * Add this script to your dashboard HTML to inject the floating chat widget.
 *
 * Usage:
 * <script src="http://localhost:5482/static/chat-widget-inject.js"></script>
 */

(function() {
    'use strict';

    const CHAT_API_URL = 'http://localhost:5482/api/chat';
    const CHAT_WIDGET_ID = 'sentry-chat-widget';

    // Check if widget is already injected
    if (document.getElementById(CHAT_WIDGET_ID)) {
        console.warn('Sentry Chat Widget already injected');
        return;
    }

    // Inject CSS
    const styles = `
        #${CHAT_WIDGET_ID} {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 9999;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            color: var(--chat-ink);
            --chat-ink: #0f172a;
            --chat-muted: #5b667a;
            --chat-primary: #0f4c5c;
            --chat-primary-2: #1b798e;
            --chat-accent: #f59e0b;
            --chat-surface: #ffffff;
            --chat-surface-2: #f6f3ef;
            --chat-border: rgba(15, 76, 92, 0.12);
            --chat-shadow: 0 18px 50px rgba(15, 23, 42, 0.18);
        }

        .sentry-chat-toggle {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--chat-primary) 0%, var(--chat-primary-2) 100%);
            border: none;
            cursor: pointer;
            box-shadow: 0 10px 24px rgba(15, 76, 92, 0.35);
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }

        .sentry-chat-toggle:hover {
            transform: scale(1.1);
            box-shadow: 0 14px 30px rgba(15, 76, 92, 0.45);
        }

        .sentry-chat-toggle svg {
            width: 28px;
            height: 28px;
            fill: white;
        }

        .sentry-chat-window {
            position: fixed;
            bottom: 90px;
            right: 20px;
            width: 400px;
            max-width: calc(100vw - 40px);
            height: 600px;
            max-height: calc(100vh - 110px);
            background: var(--chat-surface);
            border-radius: 16px;
            box-shadow: var(--chat-shadow);
            display: none;
            flex-direction: column;
            overflow: hidden;
        }

        .sentry-chat-window.open {
            display: flex;
            animation: sentrySlideUp 0.3s ease;
        }

        @keyframes sentrySlideUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .sentry-chat-header {
            background: linear-gradient(135deg, #0b2d3a 0%, var(--chat-primary) 100%);
            color: white;
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .sentry-chat-header-content {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .sentry-chat-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.18);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 14px;
        }

        .sentry-chat-title h3 {
            font-size: 16px;
            font-weight: 600;
            margin: 0 0 2px 0;
        }

        .sentry-chat-title p {
            font-size: 12px;
            opacity: 0.9;
            margin: 0;
        }

        .sentry-chat-close {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.2s;
        }

        .sentry-chat-close:hover {
            background: rgba(255, 255, 255, 0.3);
        }

        .sentry-role-selector {
            padding: 12px 20px;
            background: #f1ece4;
            border-bottom: 1px solid rgba(15, 76, 92, 0.12);
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 13px;
        }

        .sentry-role-selector label {
            color: var(--chat-muted);
            font-weight: 500;
        }

        .sentry-role-selector select {
            padding: 6px 12px;
            border: 1px solid rgba(15, 76, 92, 0.2);
            border-radius: 6px;
            background: #fffaf3;
            cursor: pointer;
            font-size: 13px;
            color: var(--chat-ink);
        }

        .sentry-chat-messages {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
            background: radial-gradient(900px 420px at 15% -10%, rgba(15, 76, 92, 0.12), transparent 60%),
                        linear-gradient(180deg, #f6f3ef 0%, #faf8f5 100%);
        }

        .sentry-message {
            margin-bottom: 16px;
            display: flex;
            gap: 10px;
            animation: sentryFadeIn 0.3s ease;
        }

        @keyframes sentryFadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .sentry-message.user {
            flex-direction: row-reverse;
        }

        .sentry-message-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--chat-primary);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: 600;
            flex-shrink: 0;
        }

        .sentry-message.user .sentry-message-avatar {
            background: var(--chat-accent);
            color: #1b1206;
        }

        .sentry-message-content {
            max-width: 75%;
        }

        .sentry-message-bubble {
            padding: 12px 16px;
            border-radius: 12px;
            background: var(--chat-surface);
            border: 1px solid var(--chat-border);
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
            word-wrap: break-word;
            line-height: 1.5;
            font-size: 14px;
            color: var(--chat-ink);
            white-space: pre-wrap;
        }

        .sentry-message.user .sentry-message-bubble {
            background: linear-gradient(135deg, var(--chat-primary) 0%, var(--chat-primary-2) 100%);
            border: none;
            color: #ffffff;
        }

        .sentry-message-time {
            font-size: 11px;
            color: var(--chat-muted);
            margin-top: 4px;
            padding: 0 4px;
        }

        .chart-card {
            margin-top: 12px;
            padding: 12px;
            border-radius: 12px;
            background: #fffaf3;
            border: 1px solid var(--chat-border);
        }

        .chart-title {
            font-size: 13px;
            font-weight: 600;
            color: var(--chat-ink);
            margin-bottom: 10px;
        }

        .chart-bars {
            display: flex;
            gap: 4px;
            align-items: flex-end;
            height: 160px;
            margin-bottom: 8px;
        }

        .chart-bar-item {
            flex: 1;
            min-width: 40px;
            max-width: 80px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 4px;
        }

        .chart-bar {
            width: 100%;
            min-height: 4px;
            border-radius: 6px;
            background: var(--chat-primary);
            transition: opacity 0.2s ease;
        }

        .chart-bar:hover {
            opacity: 0.8;
        }

        .chart-bar-value {
            font-size: 9px;
            font-weight: 600;
            color: var(--chat-ink);
            white-space: nowrap;
        }

        .chart-bar-label {
            font-size: 8px;
            color: var(--chat-muted);
            text-align: center;
            word-break: break-word;
            max-height: 32px;
            overflow: hidden;
            line-height: 1.2;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
        }

        .chart-line svg {
            width: 100%;
            height: 130px;
        }

        .chart-line-labels {
            display: flex;
            justify-content: space-between;
            font-size: 10px;
            color: var(--chat-muted);
            margin-top: 6px;
        }

        .chart-pie {
            width: 140px;
            height: 140px;
            margin: 0 auto;
            border-radius: 50%;
        }

        .chart-legend {
            margin-top: 12px;
            display: flex;
            flex-direction: column;
            gap: 6px;
        }

        .chart-legend-item {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 11px;
            color: var(--chat-muted);
        }

        .chart-legend-swatch {
            width: 10px;
            height: 10px;
            border-radius: 3px;
        }

        .sentry-typing-indicator {
            display: none;
            align-items: center;
            gap: 10px;
            margin-bottom: 16px;
        }

        .sentry-typing-indicator.active {
            display: flex;
        }

        .sentry-typing-dots {
            display: flex;
            gap: 4px;
            padding: 12px 16px;
            background: white;
            border-radius: 12px;
        }

        .sentry-typing-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: rgba(15, 76, 92, 0.35);
            animation: sentryTyping 1.4s infinite;
        }

        .sentry-typing-dot:nth-child(2) { animation-delay: 0.2s; }
        .sentry-typing-dot:nth-child(3) { animation-delay: 0.4s; }

        @keyframes sentryTyping {
            0%, 60%, 100% { transform: translateY(0); }
            30% { transform: translateY(-10px); }
        }

        .sentry-chat-input-area {
            padding: 16px 20px;
            background: var(--chat-surface);
            border-top: 1px solid rgba(15, 76, 92, 0.12);
        }

        .sentry-chat-input-container {
            display: flex;
            gap: 10px;
            align-items: flex-end;
        }

        .sentry-chat-input {
            flex: 1;
            padding: 12px 16px;
            border: 1px solid rgba(15, 76, 92, 0.2);
            border-radius: 24px;
            font-size: 14px;
            font-family: inherit;
            resize: none;
            max-height: 120px;
            background: #fffaf3;
            color: var(--chat-ink);
        }

        .sentry-chat-input:focus {
            outline: none;
            border-color: var(--chat-primary-2);
            box-shadow: 0 0 0 3px rgba(27, 121, 142, 0.15);
        }

        .sentry-chat-send-btn {
            width: 44px;
            height: 44px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--chat-primary) 0%, var(--chat-primary-2) 100%);
            border: none;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
        }

        .sentry-chat-send-btn:hover:not(:disabled) {
            transform: scale(1.05);
        }

        .sentry-chat-send-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .sentry-welcome {
            text-align: center;
            padding: 40px 20px;
            color: var(--chat-muted);
        }

        .sentry-welcome svg {
            fill: rgba(15, 76, 92, 0.25);
        }

        .sentry-welcome h4 {
            font-size: 18px;
            margin: 16px 0 8px;
            color: #495057;
        }

        .sentry-welcome p {
            font-size: 14px;
            line-height: 1.6;
            margin-bottom: 20px;
        }

        .sentry-error {
            padding: 12px;
            background: #fee;
            color: #c33;
            border-radius: 8px;
            font-size: 13px;
            margin-bottom: 16px;
        }
    `;

    const styleEl = document.createElement('style');
    styleEl.textContent = styles;
    document.head.appendChild(styleEl);

    // Create widget HTML
    const widgetHTML = `
        <div id="${CHAT_WIDGET_ID}">
            <button class="sentry-chat-toggle" aria-label="Open chat">
                <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H6l-2 2V4h16v12z"/>
                </svg>
            </button>

            <div class="sentry-chat-window">
                <div class="sentry-chat-header">
                    <div class="sentry-chat-header-content">
                        <div class="sentry-chat-avatar">SI</div>
                        <div class="sentry-chat-title">
                            <h3>Sentry Intelligence</h3>
                            <p>AI Assistant</p>
                        </div>
                    </div>
                    <button class="sentry-chat-close" aria-label="Close chat">
                        <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" style="width:16px;height:16px;fill:white;">
                            <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
                        </svg>
                    </button>
                </div>

                <div class="sentry-role-selector">
                    <label for="sentry-role">Logged as:</label>
                    <span id="sentry-role-display" style="font-weight: 600; color: #667eea; text-transform: capitalize;">Detecting...</span>
                </div>

                <div class="sentry-chat-messages">
                    <div class="sentry-welcome">
                        <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" style="width:64px;height:64px;fill:#cbd5e0;">
                            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/>
                        </svg>
                        <h4>Welcome to Sentry Intelligence</h4>
                        <p>Ask me anything about assets, devices, vulnerabilities, or our documentation!</p>
                    </div>

                    <div class="sentry-typing-indicator">
                        <div class="sentry-message-avatar">SI</div>
                        <div class="sentry-typing-dots">
                            <div class="sentry-typing-dot"></div>
                            <div class="sentry-typing-dot"></div>
                            <div class="sentry-typing-dot"></div>
                        </div>
                    </div>
                </div>

                <div class="sentry-chat-input-area">
                    <div class="sentry-chat-input-container">
                        <textarea
                            class="sentry-chat-input"
                            placeholder="Type your message..."
                            rows="1"
                        ></textarea>
                        <button class="sentry-chat-send-btn" aria-label="Send message">
                            <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" style="width:20px;height:20px;fill:white;">
                                <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;

    // Inject widget into page
    const container = document.createElement('div');
    container.innerHTML = widgetHTML;
    document.body.appendChild(container.firstElementChild);

    // Chat functionality
    class SentryChatWidget {
        constructor() {
            this.conversationHistory = [];
            this.userRole = this.detectUserRole();
            this.initElements();
            this.attachEventListeners();
            this.updateRoleDisplay();
        }

        detectUserRole() {
            // Debug: Log all localStorage keys to help troubleshooting
            console.log('🔍 Sentry Chat: Detecting user role...');
            console.log('📦 Available localStorage keys:', Object.keys(localStorage));
            console.log('🍪 Cookies:', document.cookie);

            // Strategy 0: Decode JWT Token (Kottster uses this)
            try {
                const jwtToken = localStorage.getItem('jwtToken');
                if (jwtToken) {
                    const payload = this.decodeJWT(jwtToken);
                    if (payload) {
                        console.log('✅ JWT payload decoded:', payload);

                        // Kottster stores only user ID in JWT, map ID to role
                        const roleMapping = {
                            2: 'operator',  // operator-user@uorak.com
                            3: 'manager',   // manager@uorak.com
                            4: 'admin'      // admin-user@uorak.com
                        };

                        if (payload.id && roleMapping[payload.id]) {
                            const role = roleMapping[payload.id];
                            console.log(`✅ Detected role: ${role} (from user ID: ${payload.id})`);
                            return role;
                        }

                        // Fallback: Check common JWT role fields
                        if (payload.role) return payload.role.toLowerCase();
                        if (payload.user_role) return payload.user_role.toLowerCase();
                        if (payload.userRole) return payload.userRole.toLowerCase();
                        if (payload.user?.role) return payload.user.role.toLowerCase();

                        // Fallback: Check for email to infer role
                        const email = payload.email || payload.user_email || payload.sub;
                        if (email) {
                            console.log('📧 Email found in JWT:', email);
                            if (email.includes('admin')) {
                                console.log('✅ Detected role: admin (from email)');
                                return 'admin';
                            }
                            if (email.includes('manager')) {
                                console.log('✅ Detected role: manager (from email)');
                                return 'manager';
                            }
                            if (email.includes('operator')) {
                                console.log('✅ Detected role: operator (from email)');
                                return 'operator';
                            }
                        }

                        // Fallback: Check username field
                        const username = payload.username || payload.user_name || payload.name;
                        if (username) {
                            console.log('👤 Username found in JWT:', username);
                            if (username.includes('admin')) return 'admin';
                            if (username.includes('manager')) return 'manager';
                            if (username.includes('operator')) return 'operator';
                        }
                    }
                }
            } catch (e) {
                console.error('Error decoding JWT:', e);
            }

            // Strategy 1: Check localStorage for common auth patterns
            try {
                const authKeys = ['user', 'currentUser', 'auth', 'session', 'kottster_user', 'loggedUser'];
                for (const key of authKeys) {
                    const data = localStorage.getItem(key);
                    if (data) {
                        try {
                            const parsed = JSON.parse(data);
                            // Check for role in various formats
                            if (parsed.role) return parsed.role.toLowerCase();
                            if (parsed.user?.role) return parsed.user.role.toLowerCase();
                            if (parsed.data?.role) return parsed.data.role.toLowerCase();

                            // Check for email to infer role
                            const email = parsed.email || parsed.user?.email || parsed.data?.email;
                            if (email) {
                                if (email.includes('admin')) return 'admin';
                                if (email.includes('manager')) return 'manager';
                                if (email.includes('operator')) return 'operator';
                            }
                        } catch (e) {
                            // Not JSON, skip
                        }
                    }
                }

                // Strategy 2: Check sessionStorage
                for (const key of authKeys) {
                    const data = sessionStorage.getItem(key);
                    if (data) {
                        try {
                            const parsed = JSON.parse(data);
                            if (parsed.role) return parsed.role.toLowerCase();
                            if (parsed.user?.role) return parsed.user.role.toLowerCase();
                        } catch (e) {}
                    }
                }

                // Strategy 3: Check cookies for role
                const cookies = document.cookie.split(';');
                for (const cookie of cookies) {
                    const [name, value] = cookie.trim().split('=');
                    if (name === 'user_role' || name === 'role') {
                        return value.toLowerCase();
                    }
                }

                // Strategy 4: Check for window globals
                if (window.currentUser?.role) return window.currentUser.role.toLowerCase();
                if (window.user?.role) return window.user.role.toLowerCase();

            } catch (e) {
                console.error('Error detecting user role:', e);
            }

            // Default to operator (most restrictive)
            console.warn('Could not detect user role, defaulting to operator');
            return 'operator';
        }

        decodeJWT(token) {
            try {
                // JWT has 3 parts: header.payload.signature
                const parts = token.split('.');
                if (parts.length !== 3) {
                    console.error('Invalid JWT format');
                    return null;
                }

                // Decode the payload (second part)
                const payload = parts[1];
                // Replace URL-safe characters
                const base64 = payload.replace(/-/g, '+').replace(/_/g, '/');
                // Decode base64
                const jsonPayload = decodeURIComponent(
                    atob(base64)
                        .split('')
                        .map(c => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
                        .join('')
                );

                return JSON.parse(jsonPayload);
            } catch (e) {
                console.error('Failed to decode JWT:', e);
                return null;
            }
        }

        updateRoleDisplay() {
            const roleDisplay = document.getElementById('sentry-role-display');
            if (roleDisplay) {
                roleDisplay.textContent = this.userRole;
                // Update color based on role
                const colors = {
                    admin: '#e53e3e',
                    manager: '#dd6b20',
                    operator: '#38a169'
                };
                roleDisplay.style.color = colors[this.userRole] || '#667eea';
            }
        }

        initElements() {
            this.toggle = document.querySelector('.sentry-chat-toggle');
            this.window = document.querySelector('.sentry-chat-window');
            this.closeBtn = document.querySelector('.sentry-chat-close');
            this.messages = document.querySelector('.sentry-chat-messages');
            this.input = document.querySelector('.sentry-chat-input');
            this.sendBtn = document.querySelector('.sentry-chat-send-btn');
            this.roleDisplay = document.getElementById('sentry-role-display');
            this.typing = document.querySelector('.sentry-typing-indicator');
        }

        attachEventListeners() {
            this.toggle.addEventListener('click', () => this.toggleWindow());
            this.closeBtn.addEventListener('click', () => this.closeWindow());
            this.sendBtn.addEventListener('click', () => this.sendMessage());
            this.input.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                }
            });
            this.input.addEventListener('input', () => this.resizeInput());
        }

        toggleWindow() {
            this.window.classList.toggle('open');
            if (this.window.classList.contains('open')) {
                this.input.focus();
            }
        }

        closeWindow() {
            this.window.classList.remove('open');
        }

        resizeInput() {
            this.input.style.height = 'auto';
            this.input.style.height = Math.min(this.input.scrollHeight, 120) + 'px';
        }

        addMessage(role, content, chart) {
            const welcome = this.messages.querySelector('.sentry-welcome');
            if (welcome) welcome.remove();

            const messageDiv = document.createElement('div');
            messageDiv.className = `sentry-message ${role}`;

            const time = new Date().toLocaleTimeString('en-US', {
                hour: '2-digit',
                minute: '2-digit'
            });

            const avatar = document.createElement('div');
            avatar.className = 'sentry-message-avatar';
            avatar.textContent = role === 'user' ? 'U' : 'SI';

            const contentWrap = document.createElement('div');
            contentWrap.className = 'sentry-message-content';

            const bubble = document.createElement('div');
            bubble.className = 'sentry-message-bubble';
            bubble.textContent = this.formatMessageText(content);

            const timeDiv = document.createElement('div');
            timeDiv.className = 'sentry-message-time';
            timeDiv.textContent = time;

            contentWrap.appendChild(bubble);
            contentWrap.appendChild(timeDiv);

            if (chart) {
                const chartEl = this.renderChart(chart);
                if (chartEl) {
                    contentWrap.appendChild(chartEl);
                }
            }

            messageDiv.appendChild(avatar);
            messageDiv.appendChild(contentWrap);

            this.messages.insertBefore(messageDiv, this.typing);
            this.messages.scrollTop = this.messages.scrollHeight;
        }

        escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        formatMessageText(text) {
            if (!text) {
                return '';
            }
            let formatted = text;
            formatted = formatted.replace(/\s+(?=\d+\.\s)/g, '\n');
            formatted = formatted.replace(/\s+-\s+/g, '\n- ');
            formatted = formatted.replace(/\s+\*\s+/g, '\n* ');
            return formatted;
        }

        formatNumber(value) {
            if (Number.isInteger(value)) {
                return String(value);
            }
            return value.toFixed(2);
        }

        buildBarChart(data, unit, palette) {
            const chart = document.createElement('div');
            chart.className = 'chart-bars';

            // Limit to 10 bars to prevent overcrowding
            const limitedData = data.slice(0, 10);

            // Calculate max value (handle negative values)
            const values = limitedData.map(item => Math.abs(item.value));
            const maxValue = Math.max(...values, 1);

            limitedData.forEach((item, index) => {
                const barItem = document.createElement('div');
                barItem.className = 'chart-bar-item';

                // Value label (on top)
                const barValue = document.createElement('div');
                barValue.className = 'chart-bar-value';
                barValue.textContent = `${this.formatNumber(item.value)}`;
                if (unit) {
                    barValue.textContent += ` ${unit}`;
                }

                // Bar itself
                const bar = document.createElement('div');
                bar.className = 'chart-bar';

                // Calculate height as percentage
                const heightPercent = (Math.abs(item.value) / maxValue) * 100;
                bar.style.height = `${Math.max(heightPercent, 4)}%`; // Min 4% for visibility
                bar.style.background = palette[index % palette.length];

                // Category label (bottom) - improved truncation
                const label = document.createElement('div');
                label.className = 'chart-bar-label';

                // Smart label truncation based on length
                let labelText = item.label;
                if (labelText.length > 15) {
                    // For long labels, show first few words
                    const words = labelText.split(' ');
                    if (words.length > 2) {
                        labelText = words.slice(0, 2).join(' ') + '...';
                    } else {
                        labelText = labelText.substring(0, 13) + '...';
                    }
                }

                label.textContent = labelText;
                label.title = item.label; // Full text on hover

                barItem.appendChild(barValue);
                barItem.appendChild(bar);
                barItem.appendChild(label);
                chart.appendChild(barItem);
            });

            // Add note if data was truncated
            if (data.length > 10) {
                const note = document.createElement('div');
                note.style.cssText = 'font-size: 9px; color: #9ca3af; margin-top: 8px; text-align: center;';
                note.textContent = `Showing top 10 of ${data.length} items`;
                chart.parentElement?.appendChild(note) || chart.appendChild(note);
            }

            return chart;
        }

        buildLineChart(data, unit, palette) {
            const container = document.createElement('div');
            container.className = 'chart-line';
            const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
            const width = 300;
            const height = 120;
            const padding = 14;

            const values = data.map(item => item.value);
            const maxValue = Math.max(...values, 1);
            const minValue = Math.min(...values, 0);
            const span = maxValue - minValue || 1;
            const step = data.length > 1 ? (width - padding * 2) / (data.length - 1) : 0;

            const points = data.map((item, index) => {
                const x = padding + index * step;
                const y = height - padding - ((item.value - minValue) / span) * (height - padding * 2);
                return { x, y };
            });

            const polyline = document.createElementNS('http://www.w3.org/2000/svg', 'polyline');
            polyline.setAttribute('fill', 'none');
            polyline.setAttribute('stroke', palette[0]);
            polyline.setAttribute('stroke-width', '3');
            polyline.setAttribute(
                'points',
                points.map(point => `${point.x},${point.y}`).join(' ')
            );
            svg.setAttribute('viewBox', `0 0 ${width} ${height}`);
            svg.appendChild(polyline);

            points.forEach((point, index) => {
                const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
                circle.setAttribute('cx', point.x);
                circle.setAttribute('cy', point.y);
                circle.setAttribute('r', '4');
                circle.setAttribute('fill', palette[index % palette.length]);
                svg.appendChild(circle);
            });

            container.appendChild(svg);

            const labels = document.createElement('div');
            labels.className = 'chart-line-labels';
            labels.innerHTML = `
                <span>${data[0].label}</span>
                <span>${data[data.length - 1].label}</span>
            `;
            container.appendChild(labels);

            return container;
        }

        buildPieChart(data, unit, palette) {
            const container = document.createElement('div');
            const total = data.reduce((sum, item) => sum + item.value, 0) || 1;

            let current = 0;
            const segments = data.map((item, index) => {
                const start = current;
                const slice = (item.value / total) * 100;
                current += slice;
                return `${palette[index % palette.length]} ${start}% ${current}%`;
            });

            const pie = document.createElement('div');
            pie.className = 'chart-pie';
            pie.style.background = `conic-gradient(${segments.join(', ')})`;
            container.appendChild(pie);

            const legend = document.createElement('div');
            legend.className = 'chart-legend';
            data.forEach((item, index) => {
                const row = document.createElement('div');
                row.className = 'chart-legend-item';

                const swatch = document.createElement('div');
                swatch.className = 'chart-legend-swatch';
                swatch.style.background = palette[index % palette.length];

                const label = document.createElement('div');
                label.textContent = `${item.label} (${this.formatNumber(item.value)}${unit ? ` ${unit}` : ''})`;

                row.appendChild(swatch);
                row.appendChild(label);
                legend.appendChild(row);
            });
            container.appendChild(legend);
            return container;
        }

        renderChart(chart) {
            if (!chart || !Array.isArray(chart.data) || !chart.data.length) {
                return null;
            }

            // Enhanced color palette (15 distinct colors)
            const palette = [
                '#0f4c5c', '#f59e0b', '#e76f51', '#3a86ff', '#06d6a0',
                '#ef476f', '#8338ec', '#ff6b6b', '#4ecdc4', '#ffd166',
                '#118ab2', '#fb5607', '#6d597a', '#2a9d8f', '#e63946'
            ];

            // Use all available data (backend limits to 15)
            const data = chart.data.map(item => ({
                label: String(item.label || 'Item'),
                value: Number(item.value) || 0
            }));

            const card = document.createElement('div');
            card.className = 'chart-card';

            // Title with metadata
            const title = document.createElement('div');
            title.className = 'chart-title';
            let titleText = chart.title || 'Chart';

            // Add count info if available
            if (chart.metadata && chart.metadata.count > 1) {
                titleText += ` (${chart.metadata.count} items)`;
            }

            title.textContent = titleText;
            card.appendChild(title);

            let body = null;
            if (chart.type === 'pie') {
                body = this.buildPieChart(data, chart.unit, palette);
            } else if (chart.type === 'line') {
                body = this.buildLineChart(data, chart.unit, palette);
            } else {
                body = this.buildBarChart(data, chart.unit, palette);
            }

            if (body) {
                card.appendChild(body);
            }

            // Add axis labels if provided
            if (chart.xLabel || chart.yLabel) {
                const labelsDiv = document.createElement('div');
                labelsDiv.style.cssText = 'margin-top: 8px; font-size: 10px; color: #6b7280; text-align: center;';
                if (chart.xLabel && chart.yLabel) {
                    labelsDiv.textContent = `${chart.yLabel} vs ${chart.xLabel}`;
                } else {
                    labelsDiv.textContent = chart.xLabel || chart.yLabel;
                }
                card.appendChild(labelsDiv);
            }

            return card;
        }

        showTyping() {
            this.typing.classList.add('active');
            this.messages.scrollTop = this.messages.scrollHeight;
        }

        hideTyping() {
            this.typing.classList.remove('active');
        }

        showError(message) {
            const errorDiv = document.createElement('div');
            errorDiv.className = 'sentry-error';
            errorDiv.textContent = '⚠️ ' + message;
            this.messages.insertBefore(errorDiv, this.typing);
            setTimeout(() => errorDiv.remove(), 5000);
        }

        async sendMessage() {
            const message = this.input.value.trim();
            if (!message) return;

            this.input.disabled = true;
            this.sendBtn.disabled = true;

            this.addMessage('user', message);
            this.conversationHistory.push({ role: 'user', content: message });

            this.input.value = '';
            this.input.style.height = 'auto';

            this.showTyping();

            try {
                const response = await fetch(CHAT_API_URL, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        messages: this.conversationHistory,
                        role: this.userRole
                    })
                });

                this.hideTyping();

                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}`);
                }

                const data = await response.json();
                const reply = data.reply || 'Sorry, I received an empty response.';
                const chartResult = (data.toolResults || [])
                    .find(tool => tool.name === 'generate_chart')?.result;

                this.addMessage('assistant', reply, chartResult && !chartResult.error ? chartResult : null);
                this.conversationHistory.push({ role: 'assistant', content: reply });

                if (this.conversationHistory.length > 20) {
                    this.conversationHistory = this.conversationHistory.slice(-20);
                }

            } catch (error) {
                this.hideTyping();
                console.error('Chat error:', error);
                this.showError('Failed to connect to chat server.');
            } finally {
                this.input.disabled = false;
                this.sendBtn.disabled = false;
                this.input.focus();
            }
        }
    }

    // Initialize chat when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            new SentryChatWidget();
        });
    } else {
        new SentryChatWidget();
    }

    console.log('✅ Sentry Intelligence Chat Widget injected');
})();
