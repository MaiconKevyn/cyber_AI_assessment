TOOLS = [
    {
        'type': 'function',
        'function': {
            'name': 'query_assets',
            'description': 'List assets with optional filters (name search, type).',
            'parameters': {
                'type': 'object',
                'properties': {
                    'search': {'type': 'string'},
                    'typeSlugs': {'type': 'array', 'items': {'type': 'string'}},
                    'limit': {'type': 'integer'},
                    'offset': {'type': 'integer'},
                },
                'required': [],
            },
        },
    },
    {
        'type': 'function',
        'function': {
            'name': 'query_devices',
            'description': 'List devices with optional filters (name search, asset, category).',
            'parameters': {
                'type': 'object',
                'properties': {
                    'search': {'type': 'string'},
                    'assetId': {'type': 'string'},
                    'categorySlugs': {'type': 'array', 'items': {'type': 'string'}},
                    'limit': {'type': 'integer'},
                    'offset': {'type': 'integer'},
                },
                'required': [],
            },
        },
    },
    {
        'type': 'function',
        'function': {
            'name': 'query_vulnerabilities',
            'description': 'List vulnerabilities with optional filters (title search, CVE).',
            'parameters': {
                'type': 'object',
                'properties': {
                    'search': {'type': 'string'},
                    'cve': {'type': 'string'},
                    'limit': {'type': 'integer'},
                    'offset': {'type': 'integer'},
                },
                'required': [],
            },
        },
    },
    {
        'type': 'function',
        'function': {
            'name': 'get_dashboard_stats',
            'description': '''Returns comprehensive dashboard statistics including:
- assetsTotal: Total number of assets visible to the user
- devicesTotal: Total number of devices visible to the user
- vulnerabilitiesTotal: Total number of unique vulnerabilities in the database (all CVEs)
- avgVulnerabilityAge: Average age of vulnerabilities in days (e.g., 206.33)
- devicesWithVulnerabilities: Count of devices that have at least one vulnerability
- assetsWithVulnerabilities: Count of assets that have at least one vulnerability
- uniqueVulnerabilitiesAffectingDevices: Number of unique vulnerabilities affecting visible devices

Use this function to answer questions about:
- "How many total vulnerabilities?" → vulnerabilitiesTotal
- "Average vulnerability age?" → avgVulnerabilityAge
- "Devices with vulnerabilities?" → devicesWithVulnerabilities
- "Assets with vulnerabilities?" → assetsWithVulnerabilities
''',
            'parameters': {
                'type': 'object',
                'properties': {},
            },
        },
    },
    {
        'type': 'function',
        'function': {
            'name': 'get_asset_details',
            'description': 'Fetch details and counts for a specific asset by id or name.',
            'parameters': {
                'type': 'object',
                'properties': {
                    'assetId': {'type': 'string'},
                    'name': {'type': 'string'},
                },
                'required': [],
            },
        },
    },
    {
        'type': 'function',
        'function': {
            'name': 'get_device_vulnerabilities',
            'description': 'List vulnerabilities associated with a device id.',
            'parameters': {
                'type': 'object',
                'properties': {
                    'deviceId': {'type': 'string'},
                    'limit': {'type': 'integer'},
                    'offset': {'type': 'integer'},
                },
                'required': ['deviceId'],
            },
        },
    },
    {
        'type': 'function',
        'function': {
            'name': 'get_top_vulnerabilities_by_device_count',
            'description': (
                'Return vulnerabilities with the highest number of device_vulnerabilities records.'
            ),
            'parameters': {
                'type': 'object',
                'properties': {
                    'limit': {
                        'type': 'integer',
                        'description': 'How many vulnerabilities to return (default: 5)'
                    },
                },
                'required': [],
            },
        },
    },
    {
        'type': 'function',
        'function': {
            'name': 'get_asset_distribution_by_type',
            'description': (
                'Get the count of assets grouped by their type. '
                'Returns ALL asset types without pagination. '
                'ALWAYS use this function (NOT query_assets) when creating charts/graphs of asset distribution by type. '
                'Returns accurate counts for every asset type in the system. '
                'Example: User asks "show me a pie chart of assets by type" → call this function, then generate_chart.'
            ),
            'parameters': {
                'type': 'object',
                'properties': {},
                'required': [],
            },
        },
    },
    {
        'type': 'function',
        'function': {
            'name': 'get_device_distribution_by_category',
            'description': (
                'Get the count of devices grouped by their category. '
                'Returns ALL device categories without pagination. '
                'ALWAYS use this function (NOT query_devices) when creating charts/graphs of device distribution by category. '
                'Returns accurate counts for every device category in the system. '
                'Example: User asks "show me a bar chart of devices by category" → call this function, then generate_chart.'
            ),
            'parameters': {
                'type': 'object',
                'properties': {},
                'required': [],
            },
        },
    },
    {
        'type': 'function',
        'function': {
            'name': 'generate_chart',
            'description': (
                'Generate a visual chart when the user explicitly requests visualization, graph, chart, or plot. '
                'ALWAYS call this function when user asks to "show", "visualize", "plot", "graph", or "chart" data. '
                '\n\n'
                'WORKFLOW:\n'
                '1. Call query function to get raw data (e.g., query_assets)\n'
                '2. Process/group the data by the requested dimension\n'
                '3. Call generate_chart with formatted data\n'
                '\n'
                'EXAMPLE - "Show me a pie chart of assets by type":\n'
                '  Step 1: Call query_assets() → get all assets\n'
                '  Step 2: Group assets by type_name, count each\n'
                '  Step 3: Call generate_chart({\n'
                '    "chartType": "pie",\n'
                '    "title": "Assets by Type",\n'
                '    "data": [\n'
                '      {"label": "Solar", "value": 45},\n'
                '      {"label": "Wind", "value": 32},\n'
                '      {"label": "Hydro", "value": 28}\n'
                '    ]\n'
                '  })\n'
                '\n'
                'Chart types:\n'
                '- bar: Compare categories (e.g., "assets by type", "devices per site")\n'
                '- line: Show trends over time or sequences\n'
                '- pie: Show proportions/percentages (e.g., "distribution by type")\n'
            ),
            'parameters': {
                'type': 'object',
                'properties': {
                    'chartType': {
                        'type': 'string',
                        'enum': ['bar', 'line', 'pie'],
                        'description': 'Type of chart: bar (categories), line (trends), pie (proportions)',
                    },
                    'title': {
                        'type': 'string',
                        'description': 'Descriptive chart title (e.g., "Assets by Type", "Vulnerability Severity Distribution")'
                    },
                    'data': {
                        'type': 'array',
                        'description': 'Array of data points with label and numeric value',
                        'items': {
                            'type': 'object',
                            'properties': {
                                'label': {
                                    'type': 'string',
                                    'description': 'Category name (e.g., "Solar", "Wind", "Critical")'
                                },
                                'value': {
                                    'type': 'number',
                                    'description': 'Numeric value to plot'
                                },
                            },
                            'required': ['label', 'value'],
                        },
                    },
                    'xLabel': {
                        'type': 'string',
                        'description': 'Optional X-axis label (e.g., "Asset Type", "Month")'
                    },
                    'yLabel': {
                        'type': 'string',
                        'description': 'Optional Y-axis label (e.g., "Count", "Percentage")'
                    },
                    'unit': {
                        'type': 'string',
                        'description': 'Optional unit suffix (e.g., "%", "devices", "MW")'
                    },
                },
                'required': ['chartType', 'title', 'data'],
            },
        },
    },
    {
        'type': 'function',
        'function': {
            'name': 'search_documentation',
            'description': (
                'Search company and platform documentation (Business Overview, User Manual). '
                'Use this for questions about Sentry products, features, or how to use the dashboard.'
            ),
            'parameters': {
                'type': 'object',
                'properties': {
                    'query': {
                        'type': 'string',
                        'description': 'Natural language search query'
                    },
                    'source': {
                        'type': 'string',
                        'enum': ['all', 'business_overview', 'user_manual'],
                        'description': 'Which document to search (default: all)'
                    },
                },
                'required': ['query'],
            },
        },
    },
    {
        'type': 'function',
        'function': {
            'name': 'search_nvd_cve',
            'description': (
                'Search the National Vulnerability Database (NVD) for CVE information. '
                'Use this when users explicitly ask about CVEs not in the local database, '
                'or want details from the official NVD. Supports CVE ID (e.g., CVE-2024-1234) '
                'or keyword search (e.g., "apache log4j").'
            ),
            'parameters': {
                'type': 'object',
                'properties': {
                    'query': {
                        'type': 'string',
                        'description': 'CVE ID (CVE-YYYY-NNNNN) or keyword to search'
                    },
                    'limit': {
                        'type': 'integer',
                        'description': 'Maximum number of results for keyword search (default: 5)'
                    },
                },
                'required': ['query'],
            },
        },
    },
]
