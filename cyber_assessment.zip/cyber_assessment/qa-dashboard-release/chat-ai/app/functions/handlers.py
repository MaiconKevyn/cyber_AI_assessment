from typing import Any, Dict, List

from ..services import db_service
from ..services import rag_service
from ..services import nvd_service


def normalize_pagination(args: Dict[str, Any]) -> Dict[str, int]:
    limit = args.get('limit', 50)
    offset = args.get('offset', 0)
    try:
        limit = int(limit)
    except (TypeError, ValueError):
        limit = 50
    try:
        offset = int(offset)
    except (TypeError, ValueError):
        offset = 0

    limit = max(1, min(limit, 100))
    offset = max(0, offset)
    return {'limit': limit, 'offset': offset}


def normalize_string_list(value: Any) -> List[str] | None:
    if not isinstance(value, list):
        return None
    cleaned = [str(item).strip() for item in value if str(item).strip()]
    return cleaned or None


def query_assets(args: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    pagination = normalize_pagination(args)
    items = db_service.list_assets(
        search=args.get('search'),
        type_slugs=normalize_string_list(args.get('typeSlugs')),
        role=context.get('role'),
        limit=pagination['limit'],
        offset=pagination['offset'],
    )
    total = db_service.count_assets(
        search=args.get('search'),
        type_slugs=normalize_string_list(args.get('typeSlugs')),
        role=context.get('role'),
    )
    return {
        **pagination,
        'count': total,
        'itemsCount': len(items),
        'items': items,
    }


def query_devices(args: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    pagination = normalize_pagination(args)
    items = db_service.list_devices(
        search=args.get('search'),
        asset_id=args.get('assetId'),
        category_slugs=normalize_string_list(args.get('categorySlugs')),
        role=context.get('role'),
        limit=pagination['limit'],
        offset=pagination['offset'],
    )
    return {**pagination, 'count': len(items), 'items': items}


def query_vulnerabilities(args: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    pagination = normalize_pagination(args)
    items = db_service.list_vulnerabilities(
        search=args.get('search'),
        cve=args.get('cve'),
        role=context.get('role'),
        limit=pagination['limit'],
        offset=pagination['offset'],
    )
    return {**pagination, 'count': len(items), 'items': items}


def get_dashboard_stats(args: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    return db_service.get_dashboard_stats(role=context.get('role'))


def get_asset_details(args: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    return db_service.get_asset_details(
        asset_id=args.get('assetId'),
        name=args.get('name'),
        role=context.get('role'),
    )


def get_device_vulnerabilities(args: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    pagination = normalize_pagination(args)
    device_id = args.get('deviceId')
    if not device_id:
        return {**pagination, 'count': 0, 'items': []}

    return db_service.get_device_vulnerabilities(
        device_id=device_id,
        role=context.get('role'),
        limit=pagination['limit'],
        offset=pagination['offset'],
    )


def get_top_vulnerabilities_by_device_count(
    args: Dict[str, Any],
    context: Dict[str, Any],
) -> Dict[str, Any]:
    limit = args.get('limit', 5)
    try:
        limit = int(limit)
    except (TypeError, ValueError):
        limit = 5
    limit = max(1, min(limit, 20))

    items = db_service.get_top_vulnerabilities_by_device_count(
        role=context.get('role'),
        limit=limit,
    )

    return {
        'count': len(items),
        'items': items,
        'limit': limit,
    }


def generate_chart(args: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    """
    Generate a chart configuration for visualization.
    Supports bar, line, and pie charts with up to 15 data points.
    """
    chart_type = str(args.get('chartType', 'bar')).strip().lower()
    if chart_type not in {'bar', 'line', 'pie'}:
        chart_type = 'bar'

    title = str(args.get('title', 'Chart')).strip() or 'Chart'
    unit = args.get('unit')
    x_label = args.get('xLabel')
    y_label = args.get('yLabel')

    raw_data = args.get('data') or []
    items: List[Dict[str, Any]] = []

    if isinstance(raw_data, list):
        for entry in raw_data:
            if not isinstance(entry, dict):
                continue
            label = str(entry.get('label', '')).strip()
            if not label:
                continue
            try:
                value = float(entry.get('value'))
                # Allow zero and negative values
                items.append({'label': label, 'value': value})
            except (TypeError, ValueError):
                continue

    if not items:
        return {
            'error': 'No valid data provided for chart. Each item must have "label" (string) and "value" (number).'
        }

    # Sort data by value (descending) for better visualization
    # Exception: line charts should maintain order (time series)
    if chart_type != 'line':
        items.sort(key=lambda x: x['value'], reverse=True)

    # Limit to top 15 items to avoid cluttered charts
    items = items[:15]

    # Add helpful metadata
    total = sum(item['value'] for item in items)

    return {
        'type': chart_type,
        'title': title,
        'data': items,
        'xLabel': x_label,
        'yLabel': y_label,
        'unit': unit,
        'metadata': {
            'count': len(items),
            'total': total,
            'max': max(item['value'] for item in items) if items else 0,
            'min': min(item['value'] for item in items) if items else 0,
        }
    }


def search_documentation(args: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    query = args.get('query', '').strip()
    if not query:
        return {'error': 'query is required'}

    source = args.get('source', 'all')
    limit = args.get('limit', 3)

    try:
        results = rag_service.search_documentation(
            query=query,
            source_filter=source,
            limit=limit
        )

        if not results:
            return {
                'found': False,
                'message': 'No relevant documentation found'
            }

        return {
            'found': True,
            'results': results,
            'count': len(results)
        }
    except Exception as e:
        return {'error': f'Documentation search failed: {str(e)}'}


def search_nvd_cve(args: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    query = args.get('query', '').strip()
    if not query:
        return {'error': 'query is required'}

    limit = args.get('limit', 5)

    try:
        results = nvd_service.search_cves(query=query, limit=limit)

        if not results:
            return {
                'found': False,
                'message': f'No CVE information found for: {query}'
            }

        return {
            'found': True,
            'results': results,
            'count': len(results)
        }
    except Exception as e:
        return {'error': f'NVD search failed: {str(e)}'}


def get_asset_distribution_by_type(args: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    """
    Get asset counts grouped by type - returns ALL types without pagination.
    Perfect for chart generation.
    """
    try:
        items = db_service.get_asset_distribution_by_type(role=context.get('role'))
        return {
            'count': len(items),
            'items': items,
            'total': sum(item.get('count', 0) for item in items)
        }
    except Exception as e:
        return {'error': str(e)}


def get_device_distribution_by_category(args: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    """
    Get device counts grouped by category - returns ALL categories without pagination.
    Perfect for chart generation.
    """
    try:
        items = db_service.get_device_distribution_by_category(role=context.get('role'))
        return {
            'count': len(items),
            'items': items,
            'total': sum(item.get('count', 0) for item in items)
        }
    except Exception as e:
        return {'error': str(e)}


HANDLERS = {
    'query_assets': query_assets,
    'query_devices': query_devices,
    'query_vulnerabilities': query_vulnerabilities,
    'get_dashboard_stats': get_dashboard_stats,
    'get_asset_details': get_asset_details,
    'get_device_vulnerabilities': get_device_vulnerabilities,
    'get_top_vulnerabilities_by_device_count': get_top_vulnerabilities_by_device_count,
    'get_asset_distribution_by_type': get_asset_distribution_by_type,
    'get_device_distribution_by_category': get_device_distribution_by_category,
    'generate_chart': generate_chart,
    'search_documentation': search_documentation,
    'search_nvd_cve': search_nvd_cve,
}
