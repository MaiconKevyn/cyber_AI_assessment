"""Script to index PDF documents for RAG."""
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from app.services.rag_service import index_pdf

# PDF paths - check multiple locations
PROJECT_ROOT = Path(__file__).parent.parent.parent.parent
DOCS_DIR = PROJECT_ROOT.parent / 'docs'  # /home/maiconkevyn/PycharmProjects/cyber_assessment/docs

PDFS = [
    {
        'path': DOCS_DIR / 'Sentry - Business Overview and Operating Model.pdf',
        'name': 'business_overview'
    },
    {
        'path': DOCS_DIR / 'Sentry - Dashboard User Manual.pdf',
        'name': 'user_manual'
    }
]


def main():
    """Index all PDF documents."""
    print("Starting document indexing...")
    print(f"Looking for PDFs in: {DOCS_DIR}")

    total_indexed = 0

    for pdf_info in PDFS:
        pdf_path = pdf_info['path']
        source_name = pdf_info['name']

        if not pdf_path.exists():
            print(f"Warning: PDF not found: {pdf_path}")
            continue

        try:
            count = index_pdf(pdf_path, source_name)
            total_indexed += count
            print(f"✓ Indexed {source_name}: {count} chunks\n")
        except Exception as e:
            print(f"✗ Error indexing {source_name}: {e}\n")

    print(f"\nIndexing complete! Total chunks indexed: {total_indexed}")


if __name__ == '__main__':
    main()
