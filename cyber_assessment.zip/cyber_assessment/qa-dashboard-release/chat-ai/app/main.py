from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from .config import settings
from .db import ping
from .schemas import ChatRequest, ChatResponse, HealthResponse
from .services.chat_service import run_chat

app = FastAPI(title='Sentry Chat AI')

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        'http://localhost:5480',
        'http://127.0.0.1:5480',
        'http://localhost:55480',
        'http://127.0.0.1:55480',
        'http://localhost:55481',
        'http://127.0.0.1:55481',
    ],
    allow_credentials=False,
    allow_methods=['*'],
    allow_headers=['*'],
)

static_dir = Path(__file__).resolve().parent.parent / 'static'
if static_dir.exists():
    app.mount('/static', StaticFiles(directory=static_dir), name='static')


@app.get('/', response_model=dict)
def root():
    return {'service': 'sentry-chat-ai', 'status': 'running'}


@app.get('/health', response_model=HealthResponse)
def health():
    db_ok = ping()
    return HealthResponse(status='ok', db='up' if db_ok else 'down')


@app.options('/api/chat')
def chat_options():
    return {}


@app.post('/api/chat', response_model=ChatResponse)
def chat(request: ChatRequest):
    if not request.messages:
        raise HTTPException(status_code=400, detail='messages must be provided')

    payload = [msg.model_dump() for msg in request.messages]
    result = run_chat(payload, request.role)
    return ChatResponse(**result)


def get_app() -> FastAPI:
    return app


if __name__ == '__main__':
    import uvicorn

    uvicorn.run('app.main:app', host='0.0.0.0', port=settings.port, reload=False)
