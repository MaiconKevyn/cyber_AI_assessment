import os
from dataclasses import dataclass
from dotenv import load_dotenv
from pathlib import Path

# Load .env.local if exists, otherwise .env
env_local = Path(__file__).parent.parent / '.env.local'
if env_local.exists():
    load_dotenv(env_local)
else:
    load_dotenv()

@dataclass(frozen=True)
class Settings:
    openai_api_key: str = os.getenv('OPENAI_API_KEY', '')
    openai_model: str = os.getenv('OPENAI_MODEL', 'gpt-4-turbo-preview')
    openai_embedding_model: str = os.getenv('OPENAI_EMBEDDING_MODEL', 'text-embedding-3-small')
    chat_max_tokens: int = int(os.getenv('CHAT_MAX_TOKENS', '4096'))
    chat_temperature: float = float(os.getenv('CHAT_TEMPERATURE', '0.1'))
    chat_max_history: int = int(os.getenv('CHAT_MAX_HISTORY', '10'))
    port: int = int(os.getenv('PORT', '5482'))

    db_host: str = os.getenv('DATABASE_HOST', 'db')
    db_port: int = int(os.getenv('DATABASE_PORT', '5432'))
    db_user: str = os.getenv('DATABASE_USER', 'postgres')
    db_password: str = os.getenv('DATABASE_PASSWORD', 'postgres')
    db_name: str = os.getenv('DATABASE_NAME', 'postgres')

    @property
    def database_url(self) -> str:
        return (
            f"postgresql://{self.db_user}:{self.db_password}"
            f"@{self.db_host}:{self.db_port}/{self.db_name}"
        )

settings = Settings()
