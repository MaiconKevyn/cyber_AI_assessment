from typing import Any, Dict, List, Optional
from uuid import UUID
from datetime import datetime

from psycopg_pool import ConnectionPool
from psycopg import Connection

from .config import settings

_pool: Optional[ConnectionPool] = None

def get_pool() -> ConnectionPool:
    global _pool
    if _pool is None:
        _pool = ConnectionPool(conninfo=settings.database_url, min_size=1, max_size=5)
    return _pool

def _serialize_value(value: Any) -> Any:
    """Convert non-JSON-serializable types to serializable ones."""
    if isinstance(value, UUID):
        return str(value)
    if isinstance(value, datetime):
        return value.isoformat()
    return value

def _rows_to_dicts(cursor) -> List[Dict[str, Any]]:
    columns = [col.name for col in cursor.description]
    return [
        {col: _serialize_value(val) for col, val in zip(columns, row)}
        for row in cursor.fetchall()
    ]

def fetch_all(query: str, params: Dict[str, Any]) -> List[Dict[str, Any]]:
    pool = get_pool()
    with pool.connection() as conn:  # type: Connection
        with conn.cursor() as cur:
            cur.execute(query, params)
            if cur.description is None:
                return []
            return _rows_to_dicts(cur)


def fetch_one(query: str, params: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    pool = get_pool()
    with pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute(query, params)
            if cur.description is None:
                return None
            rows = _rows_to_dicts(cur)
            return rows[0] if rows else None


def execute(query: str, params: Dict[str, Any]) -> None:
    pool = get_pool()
    with pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute(query, params)
            conn.commit()


def ping() -> bool:
    try:
        fetch_one('SELECT 1 AS ok', {})
        return True
    except Exception:
        return False
