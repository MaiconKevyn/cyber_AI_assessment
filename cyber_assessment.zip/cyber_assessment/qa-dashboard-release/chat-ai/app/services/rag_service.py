"""RAG service for document indexing and semantic search."""
import re
from pathlib import Path
from typing import Dict, List, Optional

from openai import OpenAI
from pypdf import PdfReader

from ..config import settings
from ..db import execute, fetch_all

# Initialize OpenAI client
_client = OpenAI(api_key=settings.openai_api_key)


def clean_text(text: str) -> str:
    """Clean and normalize extracted text."""
    # Remove multiple spaces
    text = re.sub(r'\s+', ' ', text)
    # Remove page numbers and headers/footers
    text = re.sub(r'\n\d+\n', '\n', text)
    return text.strip()


def chunk_text(text: str, chunk_size: int = 1000, overlap: int = 200) -> List[str]:
    """Split text into overlapping chunks."""
    chunks = []
    start = 0

    while start < len(text):
        end = start + chunk_size

        # Try to break at sentence boundary
        if end < len(text):
            # Look for sentence end near the boundary
            for delimiter in ['. ', '.\n', '.\r', '! ', '?\n']:
                last_delim = text[start:end].rfind(delimiter)
                if last_delim > chunk_size * 0.5:  # At least halfway through
                    end = start + last_delim + len(delimiter)
                    break

        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)

        start = end - overlap

    return chunks


def extract_text_from_pdf(pdf_path: Path) -> List[Dict[str, any]]:
    """Extract text from PDF with page information."""
    reader = PdfReader(str(pdf_path))
    pages_data = []

    for page_num, page in enumerate(reader.pages, start=1):
        text = page.extract_text()
        if text:
            cleaned = clean_text(text)
            if cleaned:
                pages_data.append({
                    'page_number': page_num,
                    'text': cleaned
                })

    return pages_data


def generate_embedding(text: str) -> List[float]:
    """Generate embedding using OpenAI."""
    response = _client.embeddings.create(
        model=settings.openai_embedding_model,
        input=text
    )
    return response.data[0].embedding


def index_pdf(pdf_path: Path, source_name: str) -> int:
    """Process a PDF and store chunks with embeddings in the database."""
    print(f"Processing {source_name}...")

    # Extract text from PDF
    pages_data = extract_text_from_pdf(pdf_path)
    if not pages_data:
        print(f"No text extracted from {source_name}")
        return 0

    # Combine all pages
    full_text = '\n\n'.join([p['text'] for p in pages_data])

    # Create chunks
    chunks = chunk_text(full_text, chunk_size=1000, overlap=200)
    print(f"Created {len(chunks)} chunks from {len(pages_data)} pages")

    # Delete existing chunks for this document
    execute(
        "DELETE FROM document_chunks WHERE source_file = %(source)s",
        {'source': source_name}
    )

    # Generate embeddings and store
    indexed = 0
    for i, chunk in enumerate(chunks):
        try:
            embedding = generate_embedding(chunk)

            execute(
                """
                INSERT INTO document_chunks (content, embedding, source_file, page_number)
                VALUES (%(content)s, %(embedding)s, %(source)s, %(page)s)
                """,
                {
                    'content': chunk,
                    'embedding': embedding,
                    'source': source_name,
                    'page': None  # Could be improved to track page ranges
                }
            )
            indexed += 1

            if (i + 1) % 10 == 0:
                print(f"Indexed {i + 1}/{len(chunks)} chunks...")

        except Exception as e:
            print(f"Error indexing chunk {i}: {e}")

    print(f"Successfully indexed {indexed}/{len(chunks)} chunks for {source_name}")
    return indexed


def search_documentation(
    query: str,
    source_filter: Optional[str] = None,
    limit: int = 3
) -> List[Dict]:
    """Search documentation using semantic similarity."""
    # Generate embedding for the query
    query_embedding = generate_embedding(query)

    # Build query
    where_clause = ""
    params = {
        'query_embedding': query_embedding,
        'limit': limit
    }

    if source_filter and source_filter != 'all':
        where_clause = "WHERE source_file = %(source_filter)s"
        params['source_filter'] = source_filter

    # Search using cosine similarity
    sql = f"""
        SELECT
            content,
            source_file,
            page_number,
            1 - (embedding <=> %(query_embedding)s::vector) AS similarity
        FROM document_chunks
        {where_clause}
        ORDER BY embedding <=> %(query_embedding)s::vector
        LIMIT %(limit)s
    """

    results = fetch_all(sql, params)

    return [
        {
            'content': r['content'],
            'source': r['source_file'],
            'page': r['page_number'],
            'similarity': float(r['similarity'])
        }
        for r in results
    ]
