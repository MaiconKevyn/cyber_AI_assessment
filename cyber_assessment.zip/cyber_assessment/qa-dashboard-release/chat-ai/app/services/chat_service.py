import json
import re
from typing import Any, Dict, List

from openai import OpenAI

from ..config import settings
from ..functions.definitions import TOOLS
from ..functions.handlers import HANDLERS

SYSTEM_PROMPT = (
    "You are Sentry Intelligence, an AI assistant for the Sentry Dashboard. "
    "Use the provided tools to answer questions about:\n"
    "- Assets, devices, and vulnerabilities (use query functions)\n"
    "- Aggregations like top vulnerabilities by device count (use get_top_vulnerabilities_by_device_count)\n"
    "- Company information and products (use search_documentation with 'business_overview')\n"
    "- How to use the dashboard (use search_documentation with 'user_manual')\n"
    "- CVE information from NVD (use search_nvd_cve when users explicitly request CVE details)\n\n"
    "**CHART GENERATION (CRITICAL - FOLLOW THESE STEPS EXACTLY)**:\n"
    "When the user asks to 'show', 'create', 'generate', 'visualize', 'plot', or 'chart' data:\n\n"
    "STEP 1: Query the data\n"
    "  - Use query_assets, query_devices, query_vulnerabilities, or get_dashboard_stats\n"
    "  - Get ALL relevant data (don't limit unnecessarily)\n\n"
    "STEP 2: Process and group the data\n"
    "  - Count items by category (e.g., count assets by type_name)\n"
    "  - Calculate aggregations if needed\n"
    "  - Create label-value pairs\n\n"
    "STEP 3: Call generate_chart\n"
    "  - chartType: 'bar' (categories), 'pie' (proportions), 'line' (trends)\n"
    "  - title: Clear, descriptive title\n"
    "  - data: Array of {\"label\": string, \"value\": number}\n\n"
    "CONCRETE EXAMPLE:\n"
    "User: 'Show me a pie chart of assets by type'\n"
    "You MUST:\n"
    "  1. Call get_asset_distribution_by_type() to get accurate counts for ALL types\n"
    "     (Returns: [{type_name:'Solar',count:28},{type_name:'Wind',count:71}...])\n"
    "  2. Call generate_chart({\n"
    "       chartType: 'pie',\n"
    "       title: 'Asset Distribution by Type',\n"
    "       data: [{label:'Solar',value:28},{label:'Wind',value:71}...]\n"
    "     })\n\n"
    "IMPORTANT FUNCTIONS FOR CHARTS:\n"
    "- For asset distribution: Use get_asset_distribution_by_type() NOT query_assets\n"
    "- For device distribution: Use get_device_distribution_by_category() NOT query_devices\n"
    "These specialized functions return accurate, complete counts for chart generation.\n\n"
    "IMPORTANT: You MUST call generate_chart in the SAME turn as the query function. "
    "Do NOT just describe the data - generate the chart!\n\n"
    "Only answer from tool results. If data is unavailable, say you cannot find it. "
    "Be concise and factual. Format replies for readability using short paragraphs, "
    "line breaks, and bullet lists when listing items."
)

_client = OpenAI(api_key=settings.openai_api_key)


def _run_tool_call(tool_call: Any, context: Dict[str, Any]) -> Dict[str, Any]:
    name = tool_call.function.name if tool_call.function else None
    handler = HANDLERS.get(name)
    if not handler:
        return {'error': f'Unknown tool: {name}'}

    raw_args = tool_call.function.arguments if tool_call.function else '{}'
    try:
        parsed_args = json.loads(raw_args) if raw_args else {}
    except json.JSONDecodeError as exc:
        return {'error': 'Invalid tool arguments', 'details': str(exc)}

    try:
        return handler(parsed_args, context)
    except Exception as exc:  # pragma: no cover - runtime errors
        return {'error': str(exc)}


def _tool_call_to_dict(tool_call: Any) -> Dict[str, Any]:
    if hasattr(tool_call, 'model_dump'):
        return tool_call.model_dump()
    return {
        'id': tool_call.id,
        'type': tool_call.type,
        'function': {
            'name': tool_call.function.name,
            'arguments': tool_call.function.arguments,
        },
    }


def _is_top_vulnerability_query(message: str) -> bool:
    text = (message or '').lower()
    if 'vulnerab' not in text or 'device' not in text:
        return False
    return any(keyword in text for keyword in ['most', 'highest', 'top', 'largest', 'max'])


def _is_chart_request(message: str) -> bool:
    """
    Detect if user is requesting a chart/graph visualization.
    Checks for keywords: chart, graph, plot, visualize, show.
    """
    text = (message or '').lower()
    # Match: chart, graph, plot, visualize, or "show" followed by chart-related context
    if re.search(r'\b(chart|graph|plot|visualize|visualization)\b', text):
        return True
    # Also detect "show" + "in a" + chart type (e.g., "show this in a pie chart")
    if re.search(r'\bshow\b.*\b(chart|graph|plot|pie|bar)\b', text):
        return True
    return False


def _format_top_vulnerabilities(result: Dict[str, Any]) -> str:
    items = result.get('items') or []
    if not items:
        return 'I could not find any device-linked vulnerabilities.'

    def as_int(value: Any) -> int:
        try:
            return int(value)
        except (TypeError, ValueError):
            return 0

    top_count = as_int(items[0].get('device_vuln_count'))
    top_items = [
        item for item in items
        if as_int(item.get('device_vuln_count')) == top_count
    ]

    titles = [item.get('title', 'Unknown') for item in top_items]
    if len(titles) == 1:
        return (
            f'The vulnerability with the most device-vulnerability records is '
            f'"{titles[0]}", with {top_count} records.'
        )

    joined = ', '.join(f'"{title}"' for title in titles)
    return (
        f'There is a tie for the most device-vulnerability records '
        f'({top_count} each): {joined}.'
    )


def run_chat(messages: List[Dict[str, str]], role: str = 'operator') -> Dict[str, Any]:
    context = {'role': role}
    chat_messages: List[Dict[str, Any]] = [
        {'role': 'system', 'content': SYSTEM_PROMPT},
        *messages,
    ]

    tool_results: List[Dict[str, Any]] = []

    last_user_message = next(
        (msg.get('content', '') for msg in reversed(messages) if msg.get('role') == 'user'),
        '',
    )

    chart_requested = _is_chart_request(last_user_message)

    if _is_top_vulnerability_query(last_user_message) and not chart_requested:
        result = HANDLERS['get_top_vulnerabilities_by_device_count'](
            {'limit': 5},
            context,
        )
        tool_results.append(
            {'name': 'get_top_vulnerabilities_by_device_count', 'result': result}
        )
        return {
            'reply': _format_top_vulnerabilities(result),
            'toolResults': tool_results,
        }

    # Only include generate_chart function when user explicitly requests visualization
    # This reduces token usage and prevents unnecessary chart generation
    tools = TOOLS
    if not chart_requested:
        tools = [
            tool for tool in TOOLS
            if tool.get('function', {}).get('name') != 'generate_chart'
        ]

    response = _client.chat.completions.create(
        model=settings.openai_model,
        messages=chat_messages,
        tools=tools,
        tool_choice='auto',
        temperature=settings.chat_temperature,
        max_tokens=settings.chat_max_tokens,
    )

    message = response.choices[0].message

    if message.tool_calls:
        chat_messages.append(
            {
                'role': 'assistant',
                'content': message.content or '',
                'tool_calls': [_tool_call_to_dict(tool_call) for tool_call in message.tool_calls],
            }
        )
        for tool_call in message.tool_calls:
            result = _run_tool_call(tool_call, context)
            tool_results.append({'name': tool_call.function.name, 'result': result})
            chat_messages.append(
                {
                    'role': 'tool',
                    'tool_call_id': tool_call.id,
                    'content': json.dumps(result),
                }
            )

        # Second call to LLM with tool results
        # IMPORTANT: Include tools again so LLM can call generate_chart after getting data
        response = _client.chat.completions.create(
            model=settings.openai_model,
            messages=chat_messages,
            tools=tools,  # Allow LLM to make additional tool calls (e.g., generate_chart)
            tool_choice='auto',
            temperature=settings.chat_temperature,
            max_tokens=settings.chat_max_tokens,
        )
        message = response.choices[0].message

        # Handle nested tool calls (e.g., query_assets → generate_chart)
        if message.tool_calls:
            chat_messages.append(
                {
                    'role': 'assistant',
                    'content': message.content or '',
                    'tool_calls': [_tool_call_to_dict(tool_call) for tool_call in message.tool_calls],
                }
            )
            for tool_call in message.tool_calls:
                result = _run_tool_call(tool_call, context)
                tool_results.append({'name': tool_call.function.name, 'result': result})
                chat_messages.append(
                    {
                        'role': 'tool',
                        'tool_call_id': tool_call.id,
                        'content': json.dumps(result),
                    }
                )

            # Final call to synthesize response
            response = _client.chat.completions.create(
                model=settings.openai_model,
                messages=chat_messages,
                temperature=settings.chat_temperature,
                max_tokens=settings.chat_max_tokens,
            )
            message = response.choices[0].message

    return {
        'reply': message.content or '',
        'toolResults': tool_results,
    }
