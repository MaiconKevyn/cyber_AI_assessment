from typing import Dict, List, Optional

from ..db import fetch_all, fetch_one
from ..rbac import apply_asset_type_filter, normalize_role, OPERATOR_ROLE


def _resolve_asset_type_slug(value: Optional[str]) -> Optional[str]:
    if not value:
        return None

    row = fetch_one(
        """
        SELECT slug
        FROM asset_types
        WHERE LOWER(slug) = LOWER(%(value)s)
           OR LOWER(name) = LOWER(%(value)s)
           OR LOWER(%(value)s) LIKE '%%' || LOWER(slug) || '%%'
           OR LOWER(%(value)s) LIKE '%%' || LOWER(name) || '%%'
           OR LOWER(%(value)s) LIKE '%%' || REPLACE(LOWER(slug), '_', ' ') || '%%'
        LIMIT 1
        """,
        {'value': value},
    )
    return row['slug'] if row else None


def _normalize_type_slugs(values: Optional[List[str]]) -> Optional[List[str]]:
    if not values:
        return None

    resolved: List[str] = []
    for value in values:
        if not value:
            continue
        resolved_slug = _resolve_asset_type_slug(value)
        if resolved_slug:
            resolved.append(resolved_slug)
        else:
            resolved.append(value)

    unique = list(dict.fromkeys(resolved))
    return unique or None


def _build_asset_filters(
    search: Optional[str],
    type_slugs: Optional[List[str]],
    role: Optional[str],
) -> tuple[str, Dict[str, object]]:
    normalized_type_slugs = _normalize_type_slugs(type_slugs)
    if search and not normalized_type_slugs:
        resolved_slug = _resolve_asset_type_slug(search)
        if resolved_slug:
            normalized_type_slugs = [resolved_slug]
            search = None

    where_clauses: List[str] = []
    params: Dict[str, object] = {}

    if search:
        where_clauses.append('assets.name ILIKE %(search)s')
        params['search'] = f"%{search}%"

    if normalized_type_slugs:
        where_clauses.append('asset_types.slug = ANY(%(type_slugs)s)')
        params['type_slugs'] = normalized_type_slugs

    apply_asset_type_filter(where_clauses, params, role, 'asset_types')

    where_sql = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ''
    return where_sql, params


def list_assets(
    search: Optional[str] = None,
    type_slugs: Optional[List[str]] = None,
    role: Optional[str] = None,
    limit: int = 50,
    offset: int = 0,
) -> List[Dict]:
    where_sql, params = _build_asset_filters(search, type_slugs, role)
    params['limit'] = limit
    params['offset'] = offset

    query = f"""
        SELECT assets.id, assets.name, assets.created_at,
               asset_types.name AS type_name,
               asset_types.slug AS type_slug
        FROM assets
        JOIN asset_types ON assets.type_id = asset_types.id
        {where_sql}
        ORDER BY assets.name
        LIMIT %(limit)s OFFSET %(offset)s
    """

    return fetch_all(query, params)


def count_assets(
    search: Optional[str] = None,
    type_slugs: Optional[List[str]] = None,
    role: Optional[str] = None,
) -> int:
    where_sql, params = _build_asset_filters(search, type_slugs, role)
    query = f"""
        SELECT COUNT(*) AS total
        FROM assets
        JOIN asset_types ON assets.type_id = asset_types.id
        {where_sql}
    """
    result = fetch_one(query, params)
    return int(result['total']) if result else 0


def list_devices(
    search: Optional[str] = None,
    asset_id: Optional[str] = None,
    category_slugs: Optional[List[str]] = None,
    role: Optional[str] = None,
    limit: int = 50,
    offset: int = 0,
) -> List[Dict]:
    where_clauses: List[str] = []
    params: Dict[str, object] = {
        'limit': limit,
        'offset': offset,
    }

    if search:
        where_clauses.append('devices.name ILIKE %(search)s')
        params['search'] = f"%{search}%"

    if asset_id:
        where_clauses.append('devices.asset_id = %(asset_id)s')
        params['asset_id'] = asset_id

    if category_slugs:
        where_clauses.append('device_categories.slug = ANY(%(category_slugs)s)')
        params['category_slugs'] = category_slugs

    apply_asset_type_filter(where_clauses, params, role, 'asset_types')

    where_sql = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ''

    query = f"""
        SELECT devices.id, devices.name, devices.created_at,
               assets.name AS asset_name,
               asset_types.name AS asset_type_name,
               asset_types.slug AS asset_type_slug,
               device_categories.name AS category_name,
               device_categories.slug AS category_slug
        FROM devices
        JOIN assets ON devices.asset_id = assets.id
        JOIN asset_types ON assets.type_id = asset_types.id
        JOIN device_categories ON devices.category_id = device_categories.id
        {where_sql}
        ORDER BY devices.name
        LIMIT %(limit)s OFFSET %(offset)s
    """

    return fetch_all(query, params)


def list_vulnerabilities(
    search: Optional[str] = None,
    cve: Optional[str] = None,
    role: Optional[str] = None,
    limit: int = 50,
    offset: int = 0,
) -> List[Dict]:
    where_clauses: List[str] = []
    params: Dict[str, object] = {
        'limit': limit,
        'offset': offset,
    }

    if search:
        where_clauses.append('vulnerabilities.title ILIKE %(search)s')
        params['search'] = f"%{search}%"

    if cve:
        where_clauses.append('vulnerabilities.cve = %(cve)s')
        params['cve'] = cve

    role_norm = normalize_role(role)

    if role_norm == OPERATOR_ROLE:
        apply_asset_type_filter(where_clauses, params, role, 'asset_types')
        where_sql = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ''
        query = f"""
            SELECT DISTINCT
              vulnerabilities.id,
              vulnerabilities.title,
              vulnerabilities.description,
              vulnerabilities.cve,
              vulnerabilities.discovery_date,
              vulnerabilities.created_at
            FROM vulnerabilities
            JOIN device_vulnerabilities
              ON vulnerabilities.id = device_vulnerabilities.vulnerability_id
            JOIN devices ON device_vulnerabilities.device_id = devices.id
            JOIN assets ON devices.asset_id = assets.id
            JOIN asset_types ON assets.type_id = asset_types.id
            {where_sql}
            ORDER BY vulnerabilities.discovery_date DESC
            LIMIT %(limit)s OFFSET %(offset)s
        """
        return fetch_all(query, params)

    where_sql = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ''
    query = f"""
        SELECT vulnerabilities.id, vulnerabilities.title,
               vulnerabilities.description, vulnerabilities.cve,
               vulnerabilities.discovery_date, vulnerabilities.created_at
        FROM vulnerabilities
        {where_sql}
        ORDER BY vulnerabilities.discovery_date DESC
        LIMIT %(limit)s OFFSET %(offset)s
    """

    return fetch_all(query, params)


def get_dashboard_stats(role: Optional[str] = None) -> Dict:
    where_clauses: List[str] = []
    params: Dict[str, object] = {}
    apply_asset_type_filter(where_clauses, params, role, 'asset_types')
    where_sql = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ''

    # Total assets
    assets_query = f"""
        SELECT COUNT(*) AS total
        FROM assets
        JOIN asset_types ON assets.type_id = asset_types.id
        {where_sql}
    """

    # Total devices
    devices_query = f"""
        SELECT COUNT(*) AS total
        FROM devices
        JOIN assets ON devices.asset_id = assets.id
        JOIN asset_types ON assets.type_id = asset_types.id
        {where_sql}
    """

    # Total unique vulnerabilities (all vulnerabilities in database)
    vulnerabilities_query = """
        SELECT COUNT(*) AS total
        FROM vulnerabilities
    """

    # Average vulnerability age in days
    avg_age_query = """
        SELECT AVG(EXTRACT(DAY FROM (NOW() - discovery_date))) AS avg_age
        FROM vulnerabilities
        WHERE discovery_date IS NOT NULL
    """

    # Devices with at least one vulnerability
    devices_with_vulns_query = f"""
        SELECT COUNT(DISTINCT devices.id) AS total
        FROM devices
        JOIN assets ON devices.asset_id = assets.id
        JOIN asset_types ON assets.type_id = asset_types.id
        JOIN device_vulnerabilities ON devices.id = device_vulnerabilities.device_id
        {where_sql}
    """

    # Assets with at least one vulnerability
    assets_with_vulns_query = f"""
        SELECT COUNT(DISTINCT assets.id) AS total
        FROM assets
        JOIN asset_types ON assets.type_id = asset_types.id
        JOIN devices ON assets.id = devices.asset_id
        JOIN device_vulnerabilities ON devices.id = device_vulnerabilities.device_id
        {where_sql}
    """

    # Unique vulnerabilities affecting visible devices
    unique_vulns_affecting_devices_query = f"""
        SELECT COUNT(DISTINCT vulnerabilities.id) AS total
        FROM vulnerabilities
        JOIN device_vulnerabilities ON vulnerabilities.id = device_vulnerabilities.vulnerability_id
        JOIN devices ON device_vulnerabilities.device_id = devices.id
        JOIN assets ON devices.asset_id = assets.id
        JOIN asset_types ON assets.type_id = asset_types.id
        {where_sql}
    """

    # Execute queries with safe null handling
    assets_result = fetch_one(assets_query, params)
    assets_total = int(assets_result['total']) if assets_result else 0

    devices_result = fetch_one(devices_query, params)
    devices_total = int(devices_result['total']) if devices_result else 0

    # Vulnerabilities query has no RBAC filtering (all vulnerabilities)
    vulnerabilities_result = fetch_one(vulnerabilities_query, {})
    vulnerabilities_total = int(vulnerabilities_result['total']) if vulnerabilities_result else 0

    # Average age query has no RBAC filtering
    avg_age_result = fetch_one(avg_age_query, {})
    avg_vulnerability_age = 0
    if avg_age_result and avg_age_result['avg_age'] is not None:
        avg_vulnerability_age = round(float(avg_age_result['avg_age']), 2)

    devices_with_vulns_result = fetch_one(devices_with_vulns_query, params)
    devices_with_vulns = int(devices_with_vulns_result['total']) if devices_with_vulns_result else 0

    assets_with_vulns_result = fetch_one(assets_with_vulns_query, params)
    assets_with_vulns = int(assets_with_vulns_result['total']) if assets_with_vulns_result else 0

    unique_vulns_result = fetch_one(unique_vulns_affecting_devices_query, params)
    unique_vulns_affecting_devices = int(unique_vulns_result['total']) if unique_vulns_result else 0

    return {
        'assetsTotal': assets_total,
        'devicesTotal': devices_total,
        'vulnerabilitiesTotal': vulnerabilities_total,
        'avgVulnerabilityAge': avg_vulnerability_age,
        'devicesWithVulnerabilities': devices_with_vulns,
        'assetsWithVulnerabilities': assets_with_vulns,
        'uniqueVulnerabilitiesAffectingDevices': unique_vulns_affecting_devices,
    }


def get_asset_details(
    asset_id: Optional[str] = None,
    name: Optional[str] = None,
    role: Optional[str] = None,
) -> Dict:
    if not asset_id and not name:
        return {'found': False, 'reason': 'assetId_or_name_required'}

    where_clauses: List[str] = []
    params: Dict[str, object] = {}

    if asset_id:
        where_clauses.append('assets.id = %(asset_id)s')
        params['asset_id'] = asset_id
    if name:
        where_clauses.append('assets.name ILIKE %(name)s')
        params['name'] = f"%{name}%"

    apply_asset_type_filter(where_clauses, params, role, 'asset_types')
    where_sql = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ''

    query = f"""
        SELECT assets.id, assets.name, assets.created_at,
               asset_types.name AS type_name,
               asset_types.slug AS type_slug
        FROM assets
        JOIN asset_types ON assets.type_id = asset_types.id
        {where_sql}
        ORDER BY assets.name
        LIMIT 1
    """

    asset = fetch_one(query, params)
    if not asset:
        return {'found': False}

    device_count = fetch_one(
        'SELECT COUNT(*) AS total FROM devices WHERE asset_id = %(asset_id)s',
        {'asset_id': asset['id']},
    )

    vuln_count = fetch_one(
        """
        SELECT COUNT(DISTINCT vulnerabilities.id) AS total
        FROM vulnerabilities
        JOIN device_vulnerabilities
          ON vulnerabilities.id = device_vulnerabilities.vulnerability_id
        JOIN devices ON device_vulnerabilities.device_id = devices.id
        WHERE devices.asset_id = %(asset_id)s
        """,
        {'asset_id': asset['id']},
    )

    return {
        'found': True,
        'asset': asset,
        'deviceCount': int(device_count['total']),
        'vulnerabilityCount': int(vuln_count['total']),
    }


def get_device_vulnerabilities(
    device_id: str,
    role: Optional[str] = None,
    limit: int = 50,
    offset: int = 0,
) -> Dict:
    where_clauses = ['devices.id = %(device_id)s']
    params: Dict[str, object] = {
        'device_id': device_id,
        'limit': limit,
        'offset': offset,
    }

    apply_asset_type_filter(where_clauses, params, role, 'asset_types')
    where_sql = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ''

    query = f"""
        SELECT vulnerabilities.id, vulnerabilities.title,
               vulnerabilities.description, vulnerabilities.cve,
               vulnerabilities.discovery_date, vulnerabilities.created_at
        FROM vulnerabilities
        JOIN device_vulnerabilities
          ON vulnerabilities.id = device_vulnerabilities.vulnerability_id
        JOIN devices ON device_vulnerabilities.device_id = devices.id
        JOIN assets ON devices.asset_id = assets.id
        JOIN asset_types ON assets.type_id = asset_types.id
        {where_sql}
        ORDER BY vulnerabilities.discovery_date DESC
        LIMIT %(limit)s OFFSET %(offset)s
    """

    items = fetch_all(query, params)
    return {
        'items': items,
        'count': len(items),
        'limit': limit,
        'offset': offset,
    }


def get_top_vulnerabilities_by_device_count(
    role: Optional[str] = None,
    limit: int = 5,
) -> List[Dict]:
    where_clauses: List[str] = []
    params: Dict[str, object] = {'limit': limit}

    apply_asset_type_filter(where_clauses, params, role, 'asset_types')
    where_sql = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ''

    query = f"""
        SELECT vulnerabilities.id,
               vulnerabilities.title,
               COUNT(*) AS device_vuln_count
        FROM vulnerabilities
        JOIN device_vulnerabilities
          ON vulnerabilities.id = device_vulnerabilities.vulnerability_id
        JOIN devices ON device_vulnerabilities.device_id = devices.id
        JOIN assets ON devices.asset_id = assets.id
        JOIN asset_types ON assets.type_id = asset_types.id
        {where_sql}
        GROUP BY vulnerabilities.id, vulnerabilities.title
        ORDER BY device_vuln_count DESC, vulnerabilities.title ASC
        LIMIT %(limit)s
    """

    return fetch_all(query, params)


def get_asset_distribution_by_type(role: Optional[str] = None) -> List[Dict]:
    """
    Get asset counts grouped by asset type.
    Returns ALL asset types with their counts (not paginated).
    Perfect for generating charts/graphs.
    """
    where_clauses: List[str] = []
    params: Dict[str, object] = {}
    apply_asset_type_filter(where_clauses, params, role, 'asset_types')
    where_sql = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ''

    query = f"""
        SELECT
            asset_types.name as type_name,
            asset_types.slug as type_slug,
            COUNT(assets.id) as count
        FROM assets
        JOIN asset_types ON assets.type_id = asset_types.id
        {where_sql}
        GROUP BY asset_types.id, asset_types.name, asset_types.slug
        ORDER BY count DESC, asset_types.name ASC
    """

    return fetch_all(query, params)


def get_device_distribution_by_category(role: Optional[str] = None) -> List[Dict]:
    """
    Get device counts grouped by device category.
    Returns ALL categories with their counts (not paginated).
    Perfect for generating charts/graphs.
    """
    where_clauses: List[str] = []
    params: Dict[str, object] = {}
    apply_asset_type_filter(where_clauses, params, role, 'asset_types')
    where_sql = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ''

    query = f"""
        SELECT
            device_categories.name as category_name,
            device_categories.slug as category_slug,
            COUNT(devices.id) as count
        FROM devices
        JOIN assets ON devices.asset_id = assets.id
        JOIN asset_types ON assets.type_id = asset_types.id
        JOIN device_categories ON devices.category_id = device_categories.id
        {where_sql}
        GROUP BY device_categories.id, device_categories.name, device_categories.slug
        ORDER BY count DESC, device_categories.name ASC
    """

    return fetch_all(query, params)
