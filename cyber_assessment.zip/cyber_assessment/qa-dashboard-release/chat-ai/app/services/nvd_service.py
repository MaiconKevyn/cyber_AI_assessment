"""NVD API service for CVE searches."""
import httpx
import time
import json
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from psycopg.types.json import Jsonb
from app.db import fetch_one, fetch_all, execute


# NVD API configuration
NVD_API_BASE = "https://services.nvd.nist.gov/rest/json/cves/2.0"
RATE_LIMIT_REQUESTS = 5
RATE_LIMIT_WINDOW = 30  # seconds


class RateLimiter:
    """Simple rate limiter for NVD API."""
    def __init__(self, max_requests: int, window: int):
        self.max_requests = max_requests
        self.window = window
        self.requests = []

    def wait_if_needed(self):
        """Wait if we've exceeded rate limit."""
        now = time.time()
        # Remove requests older than window
        self.requests = [req_time for req_time in self.requests if now - req_time < self.window]

        if len(self.requests) >= self.max_requests:
            # Calculate how long to wait
            oldest_request = min(self.requests)
            wait_time = self.window - (now - oldest_request) + 0.5  # Add buffer
            if wait_time > 0:
                time.sleep(wait_time)
                # Clean up again after waiting
                now = time.time()
                self.requests = [req_time for req_time in self.requests if now - req_time < self.window]

        self.requests.append(now)


# Global rate limiter instance
rate_limiter = RateLimiter(RATE_LIMIT_REQUESTS, RATE_LIMIT_WINDOW)


def get_cached_cve(cve_id: str) -> Optional[Dict]:
    """Get CVE from cache if not expired."""
    sql = """
        SELECT data
        FROM cve_cache
        WHERE cve_id = %(cve_id)s AND expires_at > now()
    """
    result = fetch_one(sql, {'cve_id': cve_id.upper()})
    return result['data'] if result else None


def cache_cve(cve_id: str, data: Dict):
    """Cache CVE data for 7 days."""
    sql = """
        INSERT INTO cve_cache (cve_id, data, fetched_at, expires_at)
        VALUES (%(cve_id)s, %(data)s, now(), now() + interval '7 days')
        ON CONFLICT (cve_id) DO UPDATE
        SET data = EXCLUDED.data,
            fetched_at = now(),
            expires_at = now() + interval '7 days'
    """
    execute(sql, {'cve_id': cve_id.upper(), 'data': Jsonb(data)})


def fetch_cve_from_nvd(cve_id: str) -> Optional[Dict]:
    """Fetch CVE details from NVD API by CVE ID."""
    rate_limiter.wait_if_needed()

    try:
        with httpx.Client(timeout=10.0) as client:
            response = client.get(f"{NVD_API_BASE}", params={'cveId': cve_id.upper()})
            response.raise_for_status()

            data = response.json()
            vulnerabilities = data.get('vulnerabilities', [])

            if not vulnerabilities:
                return None

            return parse_cve_data(vulnerabilities[0])
    except httpx.HTTPError as e:
        print(f"Error fetching CVE from NVD: {e}")
        return None


def search_cves_by_keyword(keyword: str, limit: int = 5) -> List[Dict]:
    """Search CVEs by keyword in NVD."""
    rate_limiter.wait_if_needed()

    try:
        with httpx.Client(timeout=15.0) as client:
            response = client.get(
                f"{NVD_API_BASE}",
                params={
                    'keywordSearch': keyword,
                    'resultsPerPage': min(limit, 20)  # NVD max is 2000, but we limit for performance
                }
            )
            response.raise_for_status()

            data = response.json()
            vulnerabilities = data.get('vulnerabilities', [])

            return [parse_cve_data(vuln) for vuln in vulnerabilities[:limit]]
    except httpx.HTTPError as e:
        print(f"Error searching CVEs in NVD: {e}")
        return []


def parse_cve_data(vulnerability: Dict) -> Dict:
    """Parse CVE data from NVD format to simplified format."""
    cve = vulnerability.get('cve', {})
    cve_id = cve.get('id', 'Unknown')

    # Get descriptions
    descriptions = cve.get('descriptions', [])
    description = next((d['value'] for d in descriptions if d.get('lang') == 'en'), 'No description available')

    # Get CVSS scores
    metrics = cve.get('metrics', {})
    cvss_v3 = metrics.get('cvssMetricV31', []) or metrics.get('cvssMetricV30', [])
    cvss_v2 = metrics.get('cvssMetricV2', [])

    cvss_score = None
    cvss_severity = None
    cvss_vector = None

    if cvss_v3:
        cvss_data = cvss_v3[0].get('cvssData', {})
        cvss_score = cvss_data.get('baseScore')
        cvss_severity = cvss_data.get('baseSeverity')
        cvss_vector = cvss_data.get('vectorString')
    elif cvss_v2:
        cvss_data = cvss_v2[0].get('cvssData', {})
        cvss_score = cvss_data.get('baseScore')
        cvss_severity = cvss_v2[0].get('baseSeverity')
        cvss_vector = cvss_data.get('vectorString')

    # Get references
    references = cve.get('references', [])
    reference_urls = [ref.get('url') for ref in references[:5]]  # Limit to 5 refs

    # Get published and modified dates
    published = cve.get('published', 'Unknown')
    last_modified = cve.get('lastModified', 'Unknown')

    return {
        'cve_id': cve_id,
        'description': description,
        'cvss_score': cvss_score,
        'cvss_severity': cvss_severity,
        'cvss_vector': cvss_vector,
        'published': published,
        'last_modified': last_modified,
        'references': reference_urls
    }


def get_cve_details(cve_id: str) -> Optional[Dict]:
    """Get CVE details with caching."""
    # Check cache first
    cached = get_cached_cve(cve_id)
    if cached:
        return cached

    # Fetch from NVD
    cve_data = fetch_cve_from_nvd(cve_id)
    if cve_data:
        cache_cve(cve_id, cve_data)
        return cve_data

    return None


def search_cves(query: str, limit: int = 5) -> List[Dict]:
    """
    Search CVEs by keyword or CVE ID.
    If query looks like CVE-YYYY-NNNNN, fetch specific CVE.
    Otherwise, search by keyword.
    """
    query = query.strip().upper()

    # Check if it's a CVE ID pattern
    if query.startswith('CVE-') and len(query.split('-')) == 3:
        cve_data = get_cve_details(query)
        return [cve_data] if cve_data else []

    # Otherwise search by keyword
    return search_cves_by_keyword(query, limit)
