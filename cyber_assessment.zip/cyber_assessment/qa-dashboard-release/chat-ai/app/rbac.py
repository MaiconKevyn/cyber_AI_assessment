from typing import Dict, List, Tuple

OPERATOR_ROLE = 'operator'
RESTRICTED_ASSET_TYPE_SLUGS: Tuple[str, ...] = ('battery', 'wind_offshore')


def normalize_role(role: str | None) -> str:
    if not role:
        return ''
    return str(role).strip().lower()


def apply_asset_type_filter(
    where_clauses: List[str],
    params: Dict[str, object],
    role: str | None,
    table_alias: str = 'asset_types',
) -> None:
    if normalize_role(role) != OPERATOR_ROLE:
        return

    where_clauses.append(
        f"NOT ({table_alias}.slug = ANY(%(restricted_asset_type_slugs)s))"
    )
    params['restricted_asset_type_slugs'] = list(RESTRICTED_ASSET_TYPE_SLUGS)
