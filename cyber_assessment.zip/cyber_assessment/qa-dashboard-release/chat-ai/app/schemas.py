from typing import Any, List, Optional

from pydantic import BaseModel, Field


class ChatMessage(BaseModel):
    role: str
    content: str


class ChatRequest(BaseModel):
    messages: List[ChatMessage] = Field(default_factory=list)
    role: str = 'operator'


class ChatResponse(BaseModel):
    reply: str
    toolResults: List[Any] = Field(default_factory=list)


class HealthResponse(BaseModel):
    status: str
    db: str
