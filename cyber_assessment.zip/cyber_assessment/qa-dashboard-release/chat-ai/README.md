# Sentry Intelligence - Chat AI

AI-powered chat assistant for the Sentry Dashboard that provides natural language access to assets, devices, vulnerabilities, company documentation, and CVE data from the National Vulnerability Database.

## Key Terms and Acronyms

- **CVE** ([Common Vulnerabilities and Exposures](https://cve.mitre.org/)): Standardized identifiers for publicly known cybersecurity vulnerabilities (e.g., CVE-2024-3094)
- **NVD** ([National Vulnerability Database](https://nvd.nist.gov/)): U.S. government repository of vulnerability data based on CVE identifiers, maintained by NIST
- **RAG** (Retrieval-Augmented Generation): AI technique that retrieves relevant documents before generating responses, improving accuracy with external knowledge
- **RBAC** ([Role-Based Access Control](https://csrc.nist.gov/glossary/term/role_based_access_control)): Security approach that restricts system access based on user roles
- **CVSS** ([Common Vulnerability Scoring System](https://www.first.org/cvss/)): Standard for assessing vulnerability severity (scores 0-10)
- **HNSW** (Hierarchical Navigable Small World): Graph-based algorithm for fast approximate nearest neighbor search in high-dimensional spaces
- **JWT** ([JSON Web Token](https://jwt.io/)): Compact URL-safe token format for securely transmitting information between parties

## Architecture

The system implements a hybrid approach combining three complementary strategies: OpenAI Function Calling for structured database queries, Retrieval-Augmented Generation (RAG) for document search, and external API integration for CVE lookups.

```
┌─────────────────────────────────────────────────────────┐
│                   CHAT AI SERVICE                       │
│                   (FastAPI + Python)                    │
├─────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐ │
│  │   OpenAI     │  │     RAG      │  │     NVD      │ │
│  │   GPT-4      │  │  (pgvector)  │  │     API      │ │
│  │Function Call │  │              │  │              │ │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘ │
│         │                 │                  │         │
│         ▼                 ▼                  ▼         │
│  ┌──────────────────────────────────────────────────┐ │
│  │         RBAC MIDDLEWARE (Role-based Filter)      │ │
│  └──────────────────────────────────────────────────┘ │
│         │                 │                  │         │
│         ▼                 ▼                  ▼         │
│  ┌──────────┐   ┌─────────────┐   ┌────────────────┐ │
│  │PostgreSQL│   │  Document   │   │  CVE Cache     │ │
│  │  (data)  │   │   Chunks    │   │  (7 days)      │ │
│  └──────────┘   └─────────────┘   └────────────────┘ │
└─────────────────────────────────────────────────────────┘
```

## Implementation Status

### Phase 1-3: Core Infrastructure + RBAC + Function Calling

The service runs on FastAPI (port 5482) and uses OpenAI GPT-4-turbo for intelligent query routing. Ten function tools provide database access:

- `query_assets`: List assets with filters and accurate counts
- `query_devices`: List devices with filters
- `query_vulnerabilities`: List vulnerabilities with CVE filtering
- `get_dashboard_stats`: High-level statistics (total counts)
- `get_asset_details`: Detailed asset information by ID or name
- `get_device_vulnerabilities`: Device-specific vulnerabilities
- `get_top_vulnerabilities_by_device_count`: Find vulnerabilities with most affected devices
- `generate_chart`: Generate chart configs when explicitly requested
- `search_documentation`: Semantic search in PDFs (RAG)
- `search_nvd_cve`: External CVE lookups from NVD API

**RBAC Implementation:**

The system enforces role-based access control at the database query level. Operator role cannot access BESS (Battery Energy Storage System) and Wind Offshore assets, while Admin and Manager roles have full visibility. The API expects a role value on each request and applies the filters in SQL; the default widget uses manual role selection for demos, while the backend remains the source of enforcement.

### Phase 4: RAG for Documentation

The system indexes two PDF documents into 48 chunks stored in a PostgreSQL vector database:
- Business Overview: 34 chunks
- User Manual: 14 chunks

**Technology Stack:**
- [`pypdf`](https://pypdf.readthedocs.io/) for PDF parsing
- [`pgvector`](https://github.com/pgvector/pgvector) (PostgreSQL extension) for vector storage
- [OpenAI `text-embedding-3-small`](https://platform.openai.com/docs/guides/embeddings) (1536 dimensions)
- Cosine similarity search with HNSW index
- Chunk size: 1000 characters with 200 overlap

Semantic search returns relevant documentation chunks ranked by similarity score.

#### Chunking Strategy: Sliding Window with Intelligent Boundaries

The RAG implementation uses a sliding window algorithm with boundary-aware splitting to preserve semantic context.

**Algorithm Parameters:**
```python
chunk_size = 1000  # characters
overlap = 200      # 20% overlap between chunks
boundary_aware = True  # Break at sentence boundaries
```

**Implementation:**

1. **Text Extraction** (`app/services/rag_service.py:51-66`)
   - Extract text from PDF using `pypdf`
   - Clean text: remove multiple spaces, page numbers, headers/footers
   - Combine all pages with paragraph markers

2. **Intelligent Chunking** (`app/services/rag_service.py:25-48`)
   - Start at position 0, create chunk of approximately 1000 characters
   - **Boundary Detection**: Search backwards from position 1000 for sentence delimiters:
     - `. ` (period + space) - most common
     - `.\n` (period + newline)
     - `! ` or `?\n` (exclamation/question marks)
   - If delimiter found after 50% of chunk (>500 chars), break there
   - Move forward by `chunk_size - overlap` (800 chars)
   - Repeat until end of document

3. **Rationale**

   **Overlap (200 chars):**
   ```
   Chunk 1: "...provides monitoring. The system includes"
   Chunk 2: "The system includes device discovery and..."
            ↑ Overlap ensures context preservation
   ```
   Prevents information loss at chunk boundaries. Sentences cut in one chunk appear complete in another, improving recall for edge-case queries.

   **Boundary-Aware Splitting:**
   ```
   Bad (character-exact):  "...Sentry Gua|rdian provides..."
   Good (sentence-aware):  "...real-time monitoring. |Sentry Guardian..."
   ```
   Maintains semantic integrity by avoiding mid-sentence cuts, improving embedding quality.

4. **Embedding Generation** (`app/services/rag_service.py:69-75`)
   - Each chunk generates one OpenAI `text-embedding-3-small` vector
   - 1536-dimensional vector
   - Cost: $0.020 per 1M tokens
   - Average chunk: approximately 750 tokens

5. **Storage** (`app/services/rag_service.py:107-118`)
   ```sql
   CREATE TABLE document_chunks (
       id UUID PRIMARY KEY,
       content TEXT NOT NULL,
       embedding vector(1536),  -- pgvector type
       source_file TEXT NOT NULL,
       page_number INTEGER,
       created_at TIMESTAMPTZ
   );

   -- HNSW index for fast cosine similarity search
   CREATE INDEX ON document_chunks
   USING hnsw (embedding vector_cosine_ops);
   ```

6. **Query Time Search** (`app/services/rag_service.py:131-174`)
   ```python
   # 1. Generate query embedding
   query_embedding = generate_embedding("What is Sentry Guardian?")

   # 2. Search using cosine similarity (pgvector operator: <=>)
   SELECT content, source_file,
          1 - (embedding <=> query_embedding) AS similarity
   FROM document_chunks
   ORDER BY embedding <=> query_embedding  -- Uses HNSW index
   LIMIT 3
   ```
   HNSW (Hierarchical Navigable Small World) index enables approximately O(log n) search time. Typical query latency: <500ms.

**Performance Metrics:**

| Metric | Value |
|--------|-------|
| Total chunks | 48 |
| Avg chunk size | 903.5 chars |
| Embedding size | 6.144 KB per chunk |
| Total index size | ~295 KB |
| Search latency | <500ms |
| Recall@3 | ~95% (estimated) |

**Strategy Effectiveness:**

The 1000-character chunk size balances context and precision. Smaller chunks (500) lose context and produce many irrelevant results; larger chunks (2000) dilute relevance and slow embedding generation.

The 20% overlap prevents information loss without excessive duplication. Edge information appears in multiple contexts, improving recall without doubling storage costs.

Sentence-aware splitting preserves semantic units. Embeddings capture complete thoughts instead of partial sentences that confuse the model.

The pgvector + HNSW combination provides fast similarity search without separate infrastructure, leveraging the existing PostgreSQL connection with ACID (Atomicity, Consistency, Isolation, Durability) transaction guarantees and production-ready performance.

### Phase 5: NVD Integration

The system integrates with [NVD API 2.0](https://nvd.nist.gov/developers/vulnerabilities) for CVE lookups:
- CVE lookup by ID (e.g., CVE-2024-3094)
- Keyword search (e.g., "log4j")
- 7-day caching to reduce API calls
- Rate limiting: 5 requests per 30 seconds (respects NVD limits)
- Returns: CVSS score, severity, description, references, publication dates

### Phase 8: Testing

**Unit Tests:**
- `test_rag.py`: RAG semantic search verification
- `test_nvd.py`: NVD API integration testing
- `test_e2e.py`: Complete end-to-end integration tests

**E2E Test Coverage:**
All tests passing for database queries with RBAC, documentation search, CVE lookups from NVD, and multi-tool complex queries.

## Installation & Setup

### Prerequisites

- Python 3.12+ with venv activated
- PostgreSQL with pgvector extension (running via Docker)
- OpenAI API key

### Environment Variables

Create `.env.local` in `chat-ai/` directory:

```bash
# Database (local development)
DATABASE_HOST=localhost
DATABASE_PORT=5433
DATABASE_USER=postgres
DATABASE_PASSWORD=postgres
DATABASE_NAME=postgres

# OpenAI
OPENAI_API_KEY=your-api-key-here
OPENAI_MODEL=gpt-4-turbo-preview
OPENAI_EMBEDDING_MODEL=text-embedding-3-small

# Server
PORT=5482
```

### Install Dependencies

```bash
cd /home/maiconkevyn/PycharmProjects/cyber_assessment
source .venv/bin/activate
cd qa-dashboard-release/chat-ai
pip install -r requirements.txt
```

### Initialize Database

The `pgvector` extension and tables are automatically created via Docker:

```bash
# From project root
docker-compose up -d
```

This creates:
- `document_chunks` table with vector embeddings
- `cve_cache` table for NVD results

### Index Documentation

```bash
# Activate venv and index PDFs
source .venv/bin/activate
cd qa-dashboard-release/chat-ai
python app/scripts/index_documents.py
```

Expected output:
```
Indexed business_overview: 34 chunks
Indexed user_manual: 14 chunks
Total chunks indexed: 48
```

## Running the Service

### Start the Chat API Server

```bash
source .venv/bin/activate
cd qa-dashboard-release/chat-ai
python -m app.main
```

Server runs on: `http://localhost:5482`

### Health Check

```bash
curl http://localhost:5482/health
```

Response:
```json
{
  "status": "ok",
  "db": "up"
}
```

## API Usage

### POST /api/chat

Send a chat message and receive an AI-powered response.

**Request:**
```json
{
  "messages": [
    {
      "role": "user",
      "content": "How many solar assets do we have?"
    }
  ],
  "role": "admin"
}
```

**Response:**
```json
{
  "reply": "We have 28 solar assets in total.",
  "toolResults": [
    {
      "name": "query_assets",
      "result": {
        "count": 28,
        "items": [...]
      }
    }
  ]
}
```

**Roles:**
- `admin`: Full access to all assets
- `manager`: Full access to all assets
- `operator`: Restricted access (cannot see BESS and Wind Offshore)

## Test Suite

### Run All Tests

```bash
# Test RAG functionality
python test_rag.py

# Test NVD integration
python test_nvd.py

# Test end-to-end integration
python test_e2e.py
```

### E2E Test Coverage

1. Database queries for assets
2. RBAC verification (operator vs admin)
3. RAG documentation search
4. User manual queries
5. NVD CVE lookups
6. Dashboard statistics
7. Complex multi-tool queries

## Example Queries

### Database Queries
- "List all solar assets"
- "How many devices are in the Green Valley Wind Farm?"
- "Show me all critical vulnerabilities"
- "What's the summary of the dashboard?"

### Documentation Queries
- "What is Sentry Guardian?"
- "How do I filter assets in the dashboard?"
- "What products does Sentry offer?"
- "How does the alerting system work?"

### CVE Queries
- "Tell me about CVE-2024-3094"
- "Search for log4j vulnerabilities"
- "Find CVEs related to apache"

### Complex Queries
- "What vulnerabilities exist in wind farm assets?"
- "Show me BESS assets and their device counts" (only for admin/manager)

## Project Structure

```
chat-ai/
├── app/
│   ├── db.py                     # PostgreSQL connection pool
│   ├── config.py                 # Environment configuration
│   ├── main.py                   # FastAPI application
│   ├── schemas.py                # Pydantic models
│   ├── rbac.py                   # Role-based access control
│   ├── functions/
│   │   ├── definitions.py        # OpenAI function definitions
│   │   └── handlers.py           # Function implementation
│   ├── services/
│   │   ├── chat_service.py       # OpenAI chat orchestration
│   │   ├── db_service.py         # Database query services
│   │   ├── rag_service.py        # RAG (PDF search)
│   │   └── nvd_service.py        # NVD API integration
│   └── scripts/
│       └── index_documents.py    # PDF indexing script
├── test_rag.py                   # RAG unit tests
├── test_nvd.py                   # NVD unit tests
├── test_e2e.py                   # End-to-end tests
├── requirements.txt              # Python dependencies
└── README.md                     # This file
```

## Design Decisions and Architecture Logic

### Why Hybrid Architecture? (Function Calling + RAG + External APIs)

Different query types require different approaches. Structured data (assets, devices) benefits from SQL queries, unstructured documents require semantic search, and external data (CVEs) necessitates API calls. The hybrid system routes queries intelligently.

```
User Query: "How many solar assets do we have?"
    ↓
GPT-4 analyzes intent
    ↓
Calls: query_assets(type_slugs=['solar'])
    ↓
Returns: 28 assets

User Query: "What is Sentry Guardian?"
    ↓
GPT-4 recognizes documentation query
    ↓
Calls: search_documentation(query="Sentry Guardian")
    ↓
Returns: Top 3 relevant chunks from PDFs
```

**Benefits:**
- Precision for structured queries (SQL)
- Flexibility for unstructured content (RAG)
- Up-to-date external data (NVD API)
- Single unified interface for users

---

### Why Direct OpenAI Implementation Instead of LangChain/LangGraph?

The implementation uses the OpenAI Python SDK directly without abstraction frameworks.

#### Frameworks Considered:

| Framework | Pros | Cons | Why Not Used |
|-----------|------|------|--------------|
| **LangChain** | Pre-built chains, large ecosystem | Heavy abstractions, version instability, harder debugging | Added complexity without clear benefit |
| **LangGraph** | State management, complex workflows | Overkill for simple function calling | Not needed for linear query-response flow |
| **LlamaIndex** | Document indexing focus | Opinionated RAG approach | Wanted full control over chunking strategy |
| **Haystack** | Multi-model support | Complex pipeline setup | Single LLM sufficient |

#### Why Direct Implementation:

**1. Simplicity and Clarity**

```python
# Direct OpenAI (implemented approach)
response = client.chat.completions.create(
    model="gpt-4-turbo-preview",
    messages=messages,
    tools=FUNCTION_DEFINITIONS
)

# vs LangChain (more abstraction)
from langchain.agents import initialize_agent
from langchain.chains import RetrievalQA
agent = initialize_agent(tools, llm, agent="openai-functions")
response = agent.run(query)
```

The direct implementation consists of 150 lines for chat orchestration (`chat_service.py`) with explicit control flow and no hidden logic. Debugging is straightforward since direct API calls are visible in logs.

A LangChain equivalent would require 300+ lines across multiple files with abstraction layers that obscure the actual operations. Debugging requires understanding framework internals.

**2. Performance and Control**

Direct implementation enables fine-tuned optimizations:
- **Query detection** (line 54-90 in `chat_service.py`): Bypass GPT-4 for pattern-matched queries, saving 500 tokens/query
- **Custom RAG chunking**: 1000 chars with 200 overlap, boundary-aware splitting
- **Precise error handling**: Each function call has specific error messages
- **Token optimization**: No framework overhead in context

LangChain would add framework tokens to every request, use default chunking strategies that may not be optimal, provide generic error messages, and offer less control over prompt engineering.

LangChain introduces version conflicts (frequent breaking changes), increases security surface, slows Docker builds, and makes security audits more difficult.

**3. Function Calling Simplicity**

OpenAI's native function calling already provides a high-level abstraction. Adding another layer provides diminishing returns.

**What is needed:**
```python
FUNCTION_DEFINITIONS = [
    {
        'type': 'function',
        'function': {
            'name': 'query_assets',
            'description': 'List assets with filters',
            'parameters': {...}
        }
    }
]
```

**What LangChain adds:**
```python
from langchain.tools import Tool
from langchain.agents import AgentExecutor

tools = [
    Tool(
        name="query_assets",
        func=query_assets_wrapper,
        description="List assets..."
    )
]
agent = AgentExecutor.from_agent_and_tools(...)
```

Result: More code, same functionality.


**4. Assessment-Specific Requirements**

This assessment evaluates:
- "Attention is All You Need" - Using the right tools without bloat
- Economy - Token efficiency
- Performance - Speed matters
- Security - Code auditability

Using LangChain would make it harder to demonstrate these competencies. The direct approach maintains 150 lines vs 1000s in a framework, has no framework overhead, and provides clear visibility into all operations.


---

### Why pgvector Instead of Dedicated Vector DB?

**Alternatives Considered:**
- Pinecone: SaaS, excellent performance, but additional cost + infrastructure
- Weaviate: Self-hosted, powerful, but requires separate deployment
- Qdrant: Fast, modern, but another service to maintain

**Why pgvector:**
1. Zero additional infrastructure (uses existing PostgreSQL)
2. Single connection (no need for multiple database clients)
3. ACID guarantees (transactions work across all tables)
4. Cost-effective (no additional licensing or hosting)
5. Sufficient performance (HNSW index provides <500ms search on 48 chunks)
6. Scalability (can handle 10K+ chunks with good performance)

**Trade-off:** For 100K+ chunks, dedicated vector DB might be faster, but current scale doesn't justify the added complexity.

### RBAC Logic: Database-Level vs Application-Level

The system implements database-level filtering:

```python
def list_assets(role: str):
    where_clauses = []

    # RBAC filter applied at query level
    if role == 'operator':
        where_clauses.append(
            "asset_types.slug NOT IN ('battery', 'wind_offshore')"
        )

    query = f"SELECT * FROM assets WHERE {' AND '.join(where_clauses)}"
```

**Rationale:**
- Security: LLM cannot bypass restrictions (never sees restricted data)
- Consistency: Same filter applies to all query types
- Performance: Database optimizes filtered queries
- Auditability: All queries logged with role information

**Alternative (Application-Level Filtering):**
```python
# Not implemented: Filter after fetching
all_assets = fetch_all_assets()
if role == 'operator':
    filtered = [a for a in all_assets if a.type not in restricted_types]
```

This approach fetches unnecessary data, risks LLM accidentally including restricted data in context, and may become inconsistent if filter logic diverges across query types.

### Query Detection for Top Vulnerabilities

**Challenge:** User asks "Which vulnerability affects most devices?"

**Naive Approach:** Let GPT-4 handle it with generic query_vulnerabilities tool, requiring complex aggregation in SQL or post-processing.

**Implemented Approach:** Pattern detection + specialized function

```python
def _is_top_vulnerability_query(message: str) -> bool:
    text = message.lower()
    # Check for vulnerability + device + superlative keywords
    if 'vulnerab' not in text or 'device' not in text:
        return False
    return any(kw in text for kw in ['most', 'highest', 'top', 'max'])

# If detected, directly call specialized function
if _is_top_vulnerability_query(user_message):
    result = get_top_vulnerabilities_by_device_count(limit=5)
    return format_top_vulnerabilities(result)  # Handle ties elegantly
```

**Benefits:**
- Faster: Skips GPT-4 function calling overhead
- Accurate: Pre-computed aggregation in SQL
- Consistent: Always formats ties correctly
- Cost-effective: Saves API tokens

### NVD Caching Strategy

**Problem:** NVD API is slow (2-3s) and rate-limited (5 req/30s)

**Solution:** 7-day TTL cache in PostgreSQL

```sql
CREATE TABLE cve_cache (
    cve_id TEXT PRIMARY KEY,
    data JSONB NOT NULL,
    fetched_at TIMESTAMPTZ DEFAULT now(),
    expires_at TIMESTAMPTZ DEFAULT (now() + interval '7 days')
);
```

**Logic:**
```python
def get_cve_details(cve_id: str):
    # 1. Check cache
    cached = fetch_one(
        "SELECT data FROM cve_cache WHERE cve_id = %s AND expires_at > now()",
        [cve_id]
    )
    if cached:
        return cached['data']  # <100ms

    # 2. Fetch from NVD
    rate_limiter.wait_if_needed()  # Respect 5 req/30s limit
    cve_data = fetch_from_nvd(cve_id)  # 2-3s

    # 3. Store in cache
    execute(
        "INSERT INTO cve_cache (cve_id, data) VALUES (%s, %s)",
        [cve_id, cve_data]
    )

    return cve_data
```

**Why 7 Days:**
CVE data rarely changes (published once, updated occasionally). The 7-day window balances freshness vs cache hit rate. Critical CVEs can be manually re-fetched if needed.

**Performance Impact:**
| Scenario | Latency |
|----------|---------|
| First request | 2-3s (NVD API) |
| Cached request | <100ms (PostgreSQL) |
| Hit rate (estimated) | ~80% after first day |

### Error Handling Philosophy

**Principle:** Graceful degradation, never crash

```python
try:
    results = rag_service.search_documentation(query)
    if not results:
        return {"found": False, "message": "No relevant documentation found"}
    return {"found": True, "results": results}
except Exception as e:
    # Log error but return user-friendly message
    logger.error(f"RAG search failed: {e}")
    return {"error": "Documentation search temporarily unavailable"}
```

**Rationale:**
- User always gets a response (even if limited)
- LLM can explain the limitation naturally
- Partial functionality better than complete failure
- Errors logged for debugging

**Example User Experience:**
```
User: "What is Sentry Guardian?"
[RAG service fails]
AI: "I'm currently unable to search the documentation. However, I can answer
     questions about assets, devices, and vulnerabilities from the database."
```

## Technology Stack

| Component | Technology | Justification |
|-----------|-----------|---------------|
| **LLM** | [OpenAI GPT-4-turbo](https://platform.openai.com/docs/models/gpt-4-turbo-and-gpt-4) | Best function calling, cost-effective |
| **Embeddings** | [text-embedding-3-small](https://platform.openai.com/docs/guides/embeddings) | Economical, high quality |
| **Vector DB** | [pgvector](https://github.com/pgvector/pgvector) (PostgreSQL) | No additional infrastructure |
| **PDF Parser** | [pypdf](https://pypdf.readthedocs.io/) | Lightweight, functional |
| **API Framework** | [FastAPI](https://fastapi.tiangolo.com/) | Fast, modern, async support |
| **Database Driver** | [psycopg3](https://www.psycopg.org/psycopg3/) | Connection pooling, modern |
| **HTTP Client** | [httpx](https://www.python-httpx.org/) | Async-capable, reliable |

## Assessment Requirements Met

| Requirement | Status | Implementation |
|-------------|--------|----------------|
| **1. Query dashboard data** | Complete | 8 function tools with database queries |
| **2. RBAC enforcement** | Complete | Operator restricted from BESS & Wind Offshore |
| **3. Search documentation** | Complete | RAG with 48 indexed chunks, semantic search |
| **4. Search CVEs (NVD only)** | Complete | NVD API 2.0 integration with caching |
| **5. [Bonus] Generate charts** | Complete | Chart tool + chat widget rendering |

## Performance Characteristics

- **Response Time**: 2-4 seconds for simple queries
- **Complex Queries**: 5-8 seconds (multi-tool calls)
- **RAG Search**: <500ms (HNSW index)
- **NVD API**: 2-3 seconds first call, <100ms cached
- **Concurrent Requests**: Handles 5+ simultaneous users (connection pool)

## Security Features

- Role-based access control (RBAC) enforced at query level
- Role provided in the request (chat UI/API) and filtered server-side
- Parameterized SQL queries (no SQL injection)
- API key secured in environment variables
- Rate limiting on NVD API
- No raw SQL exposure to LLM
- Input validation via Pydantic schemas

### RBAC Integration (Current)

The API expects a `role` value on each `/api/chat` request (`admin`, `manager`, or `operator`). If omitted, it defaults to `operator` (most restrictive). The default widget in `static/chat-widget.html` and `static/chat-widget-inject.js` exposes a role selector and sends that value with each request.

Backend enforcement happens in `app/rbac.py` and `app/services/db_service.py`, so restricted asset types are filtered in SQL and never reach the model.

If you want automatic role detection from the dashboard session, see `RBAC_INTEGRATION.md` for an optional approach that replaces the manual selector.

## Future Enhancements (Out of Scope)

- Additional chart types and styling refinements
- React frontend UI (Phase 7 - API ready)
- Conversation history persistence
- User authentication and sessions
- Streaming responses
- Multi-language support

## Troubleshooting

### Server won't start
```bash
# Check if port 5482 is already in use
lsof -i :5482
# Kill existing process if needed
kill -9 <PID>
```

### Database connection errors
```bash
# Verify PostgreSQL is running
docker ps | grep qa-dashboard-db
# Check connection
psql -h localhost -p 5433 -U postgres -d postgres
```

### OpenAI API errors
- Verify `OPENAI_API_KEY` in `.env.local`
- Check API quota at platform.openai.com

### NVD rate limiting
- Automatic backoff implemented
- Consider getting NVD API key for higher limits

## Contact

Developer: Maicon Kevyn
Email: osonodenewton@gmail.com
Date: January 2026
